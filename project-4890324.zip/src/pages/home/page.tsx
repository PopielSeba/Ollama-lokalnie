import { useState, useEffect, useRef } from 'react';
import LivePreview from './components/LivePreview';
import Terminal from './components/Terminal';
import ChatPanel from './components/ChatPanel';
import MultiAgentPanel from './components/MultiAgentPanel';
import FileTree from './components/FileTree';
import Header from './components/Header';
import { useGitHubSync } from '../../hooks/useGitHubSync';
import { useWorkspace } from '../../hooks/useWorkspace';

export default function Home() {
  const [htmlContent, setHtmlContent] = useState('<h1>Hello World</h1>');
  const [terminalOutput, setTerminalOutput] = useState<string[]>([]);
  const [activeFile, setActiveFile] = useState<string>('1');
  const [activeAIPanel, setActiveAIPanel] = useState<'single' | 'multi'>('multi');

  // Workspace Hook
  const {
    workspaces,
    currentWorkspace,
    currentWorkspaceId,
    files,
    messages,
    settings,
    setFiles,
    setMessages,
    setSettings,
    createWorkspace,
    deleteWorkspace,
    switchWorkspace,
    updateWorkspace,
  } = useWorkspace();

  // GitHub Sync Hook
  const { isEnabled, status, syncToGitHub, markFileChanged } = useGitHubSync(files);

  // Ustaw aktywny plik przy zmianie workspace
  useEffect(() => {
    if (files.length > 0) {
      const firstFile = files.find(f => f.type === 'file');
      if (firstFile) {
        setActiveFile(firstFile.id);
        setHtmlContent(firstFile.content || '');
      }
    }
  }, [currentWorkspaceId]);

  // Listen for GitHub sync events
  useEffect(() => {
    const handleSyncSuccess = (e: any) => {
      addTerminalOutput(`✅ Zsynchronizowano ${e.detail.filesCount} plików z GitHub`);
    };

    const handleSyncError = (e: any) => {
      addTerminalOutput(`❌ Błąd synchronizacji: ${e.detail.error}`);
    };

    const handleFilesImported = (e: any) => {
      const importedFiles = e.detail.files;
      setFiles(importedFiles);
      
      if (importedFiles.length > 0) {
        // Ustaw pierwszy plik jako aktywny
        const firstFile = importedFiles[0];
        setActiveFile(firstFile.id);
        if (firstFile.type === 'file') {
          setHtmlContent(firstFile.content || '');
        }
        
        addTerminalOutput(`✅ Zaimportowano ${importedFiles.length} plików z GitHub`);
        
        // Znajdź i wyświetl index.html lub pierwszy plik HTML
        const indexFile = importedFiles.find((f: any) => f.name === 'index.html') || 
                         importedFiles.find((f: any) => f.name.endsWith('.html'));
        if (indexFile) {
          setActiveFile(indexFile.id);
          setHtmlContent(indexFile.content || '');
          addTerminalOutput(`📄 Wyświetlam: ${indexFile.name}`);
        }
      }
    };

    window.addEventListener('github-sync-success', handleSyncSuccess);
    window.addEventListener('github-sync-error', handleSyncError);
    window.addEventListener('github-files-imported', handleFilesImported);

    return () => {
      window.removeEventListener('github-sync-success', handleSyncSuccess);
      window.removeEventListener('github-sync-error', handleSyncError);
      window.removeEventListener('github-files-imported', handleFilesImported);
    };
  }, [setFiles]);

  // Show sync status in terminal
  useEffect(() => {
    if (isEnabled && status.lastSync) {
      addTerminalOutput(`🔄 Ostatnia synchronizacja: ${status.lastSync.toLocaleString('pl-PL')}`);
    }
  }, [status.lastSync]);

  const addTerminalOutput = (text: string) => {
    setTerminalOutput(prev => [...prev, text]);
  };

  const handleFileSelect = (fileId: string) => {
    setActiveFile(fileId);
    const file = files.find(f => f.id === fileId);
    if (file && file.type === 'file') {
      setHtmlContent(file.content || '');
    }
  };

  const handleContentChange = (content: string) => {
    setHtmlContent(content);
    const updatedFiles = files.map(f => 
      f.id === activeFile ? { ...f, content } : f
    );
    setFiles(updatedFiles);

    // Mark file as changed for GitHub sync
    const file = files.find(f => f.id === activeFile);
    if (file && file.path) {
      markFileChanged(file.path);
    }
  };

  const handleManualSync = async () => {
    if (!isEnabled) {
      addTerminalOutput('⚠️ Synchronizacja GitHub nie jest skonfigurowana');
      addTerminalOutput('💡 Kliknij "Synchronizacja GitHub" aby skonfigurować');
      return;
    }

    addTerminalOutput('🔄 Rozpoczynam synchronizację z GitHub...');
    await syncToGitHub();
  };

  const handleGithubImport = async (url: string) => {
    try {
      addTerminalOutput(`🔄 Rozpoczynam import z GitHub: ${url}`);
      
      // Parse GitHub URL
      const match = url.match(/github\.com\/([^\/]+)\/([^\/]+)/);
      if (!match) {
        addTerminalOutput('❌ Błędny format URL GitHub. Użyj: https://github.com/username/repo');
        return;
      }

      const [, owner, repo] = match;
      const cleanRepo = repo.replace(/\.git$/, '');
      
      addTerminalOutput(`📡 Pobieram informacje o repozytorium ${owner}/${cleanRepo}...`);

      // Get GitHub token from config
      const savedConfig = localStorage.getItem('github-config');
      const headers: HeadersInit = {
        'Accept': 'application/vnd.github.v3+json'
      };
      
      if (savedConfig) {
        const config = JSON.parse(savedConfig);
        if (config.token) {
          headers['Authorization'] = `Bearer ${config.token}`;
          addTerminalOutput('🔑 Używam zapisanego tokena GitHub');
        }
      }

      // First, check if repo exists and get default branch
      const repoInfoResponse = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}`,
        { headers }
      );

      if (!repoInfoResponse.ok) {
        if (repoInfoResponse.status === 404) {
          addTerminalOutput('❌ Repozytorium nie zostało znalezione.');
          addTerminalOutput('💡 Możliwe przyczyny:');
          addTerminalOutput('   - Repozytorium jest prywatne (skonfiguruj token w "Synchronizacja GitHub")');
          addTerminalOutput('   - Błędny URL lub nazwa repozytorium');
          addTerminalOutput('   - Repozytorium zostało usunięte');
        } else if (repoInfoResponse.status === 403) {
          addTerminalOutput('❌ Przekroczono limit zapytań do GitHub API.');
          addTerminalOutput('💡 Spróbuj ponownie za kilka minut lub dodaj token w "Synchronizacja GitHub"');
        } else if (repoInfoResponse.status === 401) {
          addTerminalOutput('❌ Token jest nieprawidłowy lub wygasł.');
          addTerminalOutput('💡 Wygeneruj nowy token w "Synchronizacja GitHub"');
        } else {
          addTerminalOutput(`❌ Błąd GitHub API: ${repoInfoResponse.status}`);
        }
        return;
      }

      const repoInfo = await repoInfoResponse.json();
      const defaultBranch = repoInfo.default_branch || 'main';
      
      addTerminalOutput(`✅ Znaleziono repozytorium: ${repoInfo.full_name}`);
      addTerminalOutput(`📌 Domyślna gałąź: ${defaultBranch}`);
      addTerminalOutput(`🔒 Status: ${repoInfo.private ? 'Prywatne' : 'Publiczne'}`);
      addTerminalOutput(`📂 Pobieram strukturę repozytorium...`);

      // Fetch repository tree using default branch
      const treeResponse = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/git/trees/${defaultBranch}?recursive=1`,
        { headers }
      );

      if (!treeResponse.ok) {
        addTerminalOutput(`❌ Nie można pobrać struktury repozytorium (status: ${treeResponse.status})`);
        if (treeResponse.status === 409) {
          addTerminalOutput('💡 Repozytorium jest puste - dodaj pliki do repozytorium');
        }
        return;
      }

      const data = await treeResponse.json();
      await processGithubTree(data.tree, owner, cleanRepo, defaultBranch, headers, url);

    } catch (error) {
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        addTerminalOutput('❌ Błąd połączenia z GitHub API');
        addTerminalOutput('💡 Sprawdź połączenie internetowe');
      } else {
        addTerminalOutput(`❌ Błąd podczas importu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      }
    }
  };

  const processGithubTree = async (tree: any[], owner: string, repo: string, branch: string, headers: HeadersInit, githubUrl: string) => {
    addTerminalOutput(`📊 Znaleziono ${tree.length} plików/folderów`);

    // Filter files
    const fileItems = tree.filter((item: any) => 
      item.type === 'blob' && 
      !item.path.includes('node_modules') &&
      !item.path.includes('.git/') &&
      item.size < 1000000 // Skip files larger than 1MB
    );

    addTerminalOutput(`📥 Pobieram ${fileItems.length} plików...`);

    const allItems: any[] = [];
    let successCount = 0;
    let errorCount = 0;

    // Fetch file contents (increased to 100 files)
    const filesToFetch = fileItems.slice(0, 100);
    
    for (const file of filesToFetch) {
      try {
        // Use GitHub API instead of raw.githubusercontent.com for private repos
        const response = await fetch(
          `https://api.github.com/repos/${owner}/${repo}/contents/${file.path}?ref=${branch}`,
          { headers }
        );

        if (response.ok) {
          const data = await response.json();
          
          // 🔧 NAPRAWIONE: Prawidłowe dekodowanie base64 → UTF-8 dla polskich znaków
          let content = '';
          try {
            // Usuń znaki nowej linii z base64
            const base64Content = data.content.replace(/\n/g, '');
            
            // Dekoduj base64 do binarnych danych
            const binaryString = atob(base64Content);
            
            // Konwertuj binary string do Uint8Array
            const bytes = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) {
              bytes[i] = binaryString.charCodeAt(i);
            }
            
            // Dekoduj UTF-8 bajty do tekstu (zachowuje polskie znaki!)
            const decoder = new TextDecoder('utf-8');
            content = decoder.decode(bytes);
            
          } catch (decodeError) {
            console.error(`Błąd dekodowania ${file.path}:`, decodeError);
            // Fallback do starej metody
            content = atob(data.content.replace(/\n/g, ''));
          }
          
          const pathParts = file.path.split('/');
          const fileName = pathParts[pathParts.length - 1];
          
          // Create all parent folders
          for (let i = 1; i < pathParts.length; i++) {
            const folderPath = pathParts.slice(0, i).join('/');
            const folderName = pathParts[i - 1];
            const parentPath = i > 1 ? pathParts.slice(0, i - 1).join('/') : null;
            
            // Check if folder already exists
            if (!allItems.find(item => item.path === folderPath && item.type === 'folder')) {
              allItems.push({
                id: `folder-${folderPath}`,
                name: folderName,
                path: folderPath,
                parentPath: parentPath,
                type: 'folder',
                isOpen: false,
                children: []
              });
            }
          }
          
          // Add file
          const parentPath = pathParts.length > 1 ? pathParts.slice(0, -1).join('/') : null;
          
          allItems.push({
            id: file.sha,
            name: fileName,
            path: file.path,
            parentPath: parentPath,
            type: 'file',
            content
          });
          successCount++;
        } else {
          errorCount++;
          console.error(`Błąd pobierania ${file.path}:`, response.status);
        }

        // Add progress log every 10 files
        if ((successCount + errorCount) % 10 === 0) {
          addTerminalOutput(`⏳ Pobrano ${successCount} z ${filesToFetch.length} plików...`);
        }

      } catch (error) {
        errorCount++;
        console.error(`Błąd pobierania pliku:`, error);
      }
    }

    if (allItems.length > 0) {
      // Sort: folders first, then files
      const sortedItems = allItems.sort((a, b) => {
        if (a.type === 'folder' && b.type === 'file') return -1;
        if (a.type === 'file' && b.type === 'folder') return 1;
        return a.path.localeCompare(b.path);
      });
      
      // Utwórz nowy workspace dla tego projektu
      const repoName = repo.replace(/\.git$/, '');
      const newWorkspace = createWorkspace(
        repoName,
        `Projekt z GitHub: ${owner}/${repoName}`,
        githubUrl
      );
      
      // WAŻNE: Ustaw pliki DOPIERO PO utworzeniu workspace
      // Daj czas na przełączenie workspace (useEffect w useWorkspace)
      setTimeout(() => {
        setFiles(sortedItems);
        
        // Set first file as active
        const firstFile = sortedItems.find(item => item.type === 'file');
        if (firstFile) {
          setActiveFile(firstFile.id);
          setHtmlContent(firstFile.content || '');
        }
        
        const folderCount = sortedItems.filter(item => item.type === 'folder').length;
        const fileCount = sortedItems.filter(item => item.type === 'file').length;
        
        addTerminalOutput(`✅ Import zakończony! Pobrano ${folderCount} folderów i ${fileCount} plików${errorCount > 0 ? `, ${errorCount} błędów` : ''}`);
        addTerminalOutput(`📦 Utworzono nowy workspace: ${newWorkspace.name}`);
        
        // Find and preview index.html or first HTML file
        const indexFile = sortedItems.find(f => f.name === 'index.html') || 
                         sortedItems.find(f => f.name.endsWith('.html'));
        if (indexFile) {
          setActiveFile(indexFile.id);
          setHtmlContent(indexFile.content || '');
          addTerminalOutput(`🌐 Wyświetlam podgląd: ${indexFile.name}`);
        }
      }, 100);
      
    } else {
      addTerminalOutput('❌ Nie udało się pobrać żadnych plików');
      if (errorCount > 0) {
        addTerminalOutput(`💡 Sprawdź czy token ma uprawnienia "repo"`);
      }
    }

    if (fileItems.length > 100) {
      addTerminalOutput(`⚠️ Uwaga: Repozytorium zawiera ${fileItems.length} plików. Pobrano pierwsze 100.`);
    }
  };

  const handleMultiAgentAction = (action: any) => {
    if (!action || !action.action) return;

    const actionData = action.action;
    
    addTerminalOutput(`🤖 Multi-Agent AI: ${action.analysis || 'Wykonuję akcję...'}`);

    try {
      switch (actionData.type) {
        case 'create_file': {
          if (!actionData.path || !actionData.content) break;
          
          const pathParts = actionData.path.split('/');
          const fileName = pathParts[pathParts.length - 1];
          const parentPath = pathParts.slice(0, -1).join('/');
          
          const newFile = {
            id: `file-${Date.now()}`,
            name: fileName,
            path: actionData.path,
            parentPath: parentPath || null,
            type: 'file',
            content: actionData.content
          };
          
          setFiles([...files, newFile]);
          setActiveFile(newFile.id);
          setHtmlContent(actionData.content);
          addTerminalOutput(`✅ Utworzono plik: ${actionData.path}`);
          break;
        }

        case 'edit_file': {
          if (!actionData.path || !actionData.content) break;
          
          const fileToEdit = files.find(f => f.path === actionData.path);
          if (fileToEdit) {
            const updatedFiles = files.map(f => 
              f.path === actionData.path ? { ...f, content: actionData.content } : f
            );
            setFiles(updatedFiles);
            setActiveFile(fileToEdit.id);
            setHtmlContent(actionData.content);
            addTerminalOutput(`✅ Zaktualizowano plik: ${actionData.path}`);
          } else {
            addTerminalOutput(`⚠️ Plik nie znaleziony: ${actionData.path}`);
          }
          break;
        }

        case 'delete_file': {
          if (!actionData.path) break;
          
          const updatedFiles = files.filter(f => f.path !== actionData.path);
          setFiles(updatedFiles);
          addTerminalOutput(`✅ Usunięto plik: ${actionData.path}`);
          break;
        }

        default:
          addTerminalOutput(`⚠️ Nieznany typ akcji: ${actionData.type}`);
      }
    } catch (error) {
      addTerminalOutput(`❌ Błąd wykonania akcji: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#1e1e1e] text-gray-200">
      <Header 
        onGithubImport={handleGithubImport}
        onManualSync={handleManualSync}
        isSyncing={status.isSyncing}
        workspaces={workspaces}
        currentWorkspace={currentWorkspace}
        onCreateWorkspace={createWorkspace}
        onSwitchWorkspace={switchWorkspace}
        onDeleteWorkspace={deleteWorkspace}
        onUpdateWorkspace={updateWorkspace}
      />
      
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - AI Assistant */}
        <div className="w-1/4 border-r border-gray-700 flex flex-col">
          {/* AI Panel Switcher */}
          <div className="flex-shrink-0 bg-[#2d2d30] border-b border-gray-700 flex">
            <button
              onClick={() => setActiveAIPanel('multi')}
              className={`flex-1 px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
                activeAIPanel === 'multi'
                  ? 'bg-[#1e1e1e] text-white border-b-2 border-purple-500'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <i className="ri-team-line mr-2"></i>
              Multi-Agent AI
            </button>
            <button
              onClick={() => setActiveAIPanel('single')}
              className={`flex-1 px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
                activeAIPanel === 'single'
                  ? 'bg-[#1e1e1e] text-white border-b-2 border-blue-500'
                  : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <i className="ri-robot-2-line mr-2"></i>
              Single AI
            </button>
          </div>

          {/* AI Panel Content */}
          <div className="flex-1 overflow-hidden">
            {activeAIPanel === 'multi' ? (
              <MultiAgentPanel 
                projectContext={{
                  files: files,
                  structure: files.reduce((acc: any, file) => {
                    if (file.type === 'folder') {
                      acc.folders = acc.folders || [];
                      acc.folders.push(file.path);
                    } else {
                      acc.files = acc.files || [];
                      acc.files.push(file.path);
                    }
                    return acc;
                  }, {})
                }}
                onActionGenerated={handleMultiAgentAction}
                onTerminalOutput={addTerminalOutput}
              />
            ) : (
              <ChatPanel 
                onTerminalOutput={addTerminalOutput}
                files={files}
                onFilesChange={setFiles}
                onFileSelect={handleFileSelect}
                messages={messages}
                onMessagesChange={setMessages}
                settings={settings}
                onSettingsChange={setSettings}
              />
            )}
          </div>
        </div>

        {/* Center Panel - Live Preview & Terminal */}
        <div className="flex-1 flex flex-col">
          {/* Live Preview - 2/3 of center area */}
          <div className="h-2/3 border-b border-gray-700">
            <LivePreview htmlContent={htmlContent} />
          </div>

          {/* Terminal - 1/3 of center area */}
          <div className="h-1/3">
            <Terminal output={terminalOutput} onCommand={addTerminalOutput} />
          </div>
        </div>

        {/* Right Panel - File Tree */}
        <div className="w-1/4 border-l border-gray-700">
          <FileTree 
            files={files} 
            activeFile={activeFile}
            onFileSelect={handleFileSelect}
            onFilesChange={setFiles}
          />
        </div>
      </div>

      {/* GitHub Sync Status Indicator */}
      {isEnabled && (
        <div className="fixed bottom-4 right-4 bg-[#2d2d30] border border-gray-700 rounded-lg px-4 py-2 shadow-lg flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${status.isSyncing ? 'bg-yellow-500 animate-pulse' : status.error ? 'bg-red-500' : 'bg-green-500'}`}></div>
          <span className="text-xs text-gray-300">
            {status.isSyncing ? 'Synchronizacja...' : status.error ? 'Błąd synchronizacji' : 'GitHub połączony'}
          </span>
          {status.lastSync && !status.isSyncing && (
            <span className="text-xs text-gray-500">
              • {new Date(status.lastSync).toLocaleTimeString('pl-PL')}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
