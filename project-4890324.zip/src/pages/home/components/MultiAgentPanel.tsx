import { useState, useEffect, useRef } from 'react';
import { useMultiAgentAI } from '../../../hooks/useMultiAgentAI';
import type { AIAgent, Task, AgentMessage } from '../../../hooks/useMultiAgentAI';

interface MultiAgentPanelProps {
  projectContext: any;
  onActionGenerated?: (action: any) => void;
  onTerminalOutput: (text: string) => void;
}

export default function MultiAgentPanel({ projectContext, onActionGenerated, onTerminalOutput }: MultiAgentPanelProps) {
  const {
    agents,
    tasks,
    messages,
    isProcessing,
    settings,
    availableModels,
    ollamaConnected,
    isTestingConnection,
    processQuery,
    clearMessages,
    clearTasks,
    stopProcessing,
    testOllamaConnection,
    loadAvailableModels,
    updateSettings
  } = useMultiAgentAI(onTerminalOutput);

  const [userInput, setUserInput] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [tempSettings, setTempSettings] = useState(settings);
  const [showSaveSuccess, setShowSaveSuccess] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    setTempSettings(settings);
  }, [settings]);

  useEffect(() => {
    testOllamaConnection();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || isProcessing) return;

    const query = userInput.trim();
    setUserInput('');

    // Dodaj wiadomość użytkownika do czatu
    const userMessage: AgentMessage = {
      id: `msg-${Date.now()}`,
      agent: 'system',
      content: query,
      type: 'info',
      timestamp: new Date(),
    };
    
    // Ręcznie dodaj wiadomość użytkownika
    const currentMessages = messages;
    const newMessages = [...currentMessages, userMessage];

    const results = await processQuery(query, projectContext);
    
    if (results.length > 0 && onActionGenerated) {
      results.forEach(result => onActionGenerated(result));
    }
  };

  const handleSaveSettings = () => {
    updateSettings(tempSettings);
    setShowSaveSuccess(true);
    setTimeout(() => setShowSaveSuccess(false), 3000);
  };

  const handleModelChange = (agent: 'router' | 'planner' | 'coder', value: string) => {
    if (agent === 'router') {
      setTempSettings({ ...tempSettings, routerModel: value });
    } else if (agent === 'planner') {
      setTempSettings({ ...tempSettings, plannerModel: value });
    } else if (agent === 'coder') {
      setTempSettings({ ...tempSettings, coderModel: value });
    }
  };

  const getAgentStatusColor = (status: AIAgent['status']) => {
    switch (status) {
      case 'active': return 'bg-green-500';
      case 'loading': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-400';
    }
  };

  const getAgentStatusText = (status: AIAgent['status']) => {
    switch (status) {
      case 'active': return 'AKTYWNY';
      case 'loading': return 'ŁADOWANIE';
      case 'error': return 'BŁĄD';
      default: return 'BEZCZYNNY';
    }
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-50';
      case 'medium': return 'text-yellow-600 bg-yellow-50';
      case 'low': return 'text-blue-600 bg-blue-50';
    }
  };

  const getPriorityText = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'WYSOKI';
      case 'medium': return 'ŚREDNI';
      case 'low': return 'NISKI';
    }
  };

  const getTaskStatusIcon = (status: Task['status']) => {
    switch (status) {
      case 'completed': return '✅';
      case 'in_progress': return '⏳';
      case 'failed': return '❌';
      default: return '⏸️';
    }
  };

  const getTaskStatusText = (status: Task['status']) => {
    switch (status) {
      case 'completed': return 'UKOŃCZONE';
      case 'in_progress': return 'W TRAKCIE';
      case 'failed': return 'BŁĄD';
      default: return 'OCZEKUJE';
    }
  };

  const getAgentIcon = (agent: AgentMessage['agent']) => {
    switch (agent) {
      case 'router': return '🎯';
      case 'planner': return '🧠';
      case 'coder': return '💻';
      default: return '👤';
    }
  };

  const getAgentName = (agent: AgentMessage['agent']) => {
    switch (agent) {
      case 'router': return 'Router';
      case 'planner': return 'Planner';
      case 'coder': return 'Coder';
      default: return 'Ty';
    }
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress');
  const completedTasks = tasks.filter(t => t.status === 'completed');
  const failedTasks = tasks.filter(t => t.status === 'failed');

  const activeAgent = agents.find(a => a.status === 'active');

  // Filtruj wiadomości - pokaż tylko odpowiedzi agentów (bez logów technicznych)
  const chatMessages = messages.filter(m => m.agent !== 'system' || m.content.includes('Przetwarzam:'));

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e]">
      {/* Header */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-gray-700 bg-[#2d2d30]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <i className="ri-robot-2-line text-2xl text-purple-400"></i>
            <h2 className="text-lg font-bold text-gray-100">Multi-Agent AI System</h2>
            <div className={`ml-2 w-2 h-2 rounded-full ${ollamaConnected ? 'bg-green-500' : 'bg-red-500'}`} title={ollamaConnected ? 'Połączono z Ollama' : 'Brak połączenia'}></div>
          </div>
          <div className="flex items-center gap-2">
            {isProcessing && (
              <button
                onClick={stopProcessing}
                className="px-3 py-1 text-sm font-medium text-white bg-red-500 hover:bg-red-600 rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-stop-circle-line mr-1"></i>
                Zatrzymaj
              </button>
            )}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="px-3 py-1 text-sm font-medium text-gray-300 bg-[#3e3e42] hover:bg-[#4e4e52] rounded-md transition-colors whitespace-nowrap cursor-pointer"
              title="Ustawienia"
            >
              <i className="ri-settings-3-line"></i>
            </button>
            <button
              onClick={clearMessages}
              className="px-3 py-1 text-sm font-medium text-gray-300 bg-[#3e3e42] hover:bg-[#4e4e52] rounded-md transition-colors whitespace-nowrap cursor-pointer"
              title="Wyczyść wiadomości"
            >
              <i className="ri-delete-bin-line"></i>
            </button>
            <button
              onClick={clearTasks}
              className="px-3 py-1 text-sm font-medium text-gray-300 bg-[#3e3e42] hover:bg-[#4e4e52] rounded-md transition-colors whitespace-nowrap cursor-pointer"
              title="Wyczyść zadania"
            >
              <i className="ri-file-list-3-line"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="flex-shrink-0 px-4 py-3 border-b border-gray-700 bg-[#252526] space-y-3">
          {/* Ollama URL */}
          <div>
            <label className="text-xs text-gray-400 mb-1 block font-medium">Adres Ollama</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={tempSettings.ollamaUrl}
                onChange={(e) => setTempSettings({ ...tempSettings, ollamaUrl: e.target.value })}
                placeholder="http://localhost:11434"
                className="flex-1 px-3 py-2 bg-[#3c3c3c] border border-gray-600 rounded-md text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
              <button
                onClick={testOllamaConnection}
                disabled={isTestingConnection}
                className="px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-md whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
                title="Test połączenia"
              >
                {isTestingConnection ? (
                  <i className="ri-loader-4-line animate-spin"></i>
                ) : (
                  <i className="ri-link"></i>
                )}
              </button>
              <button
                onClick={loadAvailableModels}
                disabled={isTestingConnection}
                className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-md whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
                title="Odśwież modele"
              >
                <i className="ri-refresh-line"></i>
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              <i className="ri-information-line mr-1"></i>
              {ollamaConnected ? `Połączono - znaleziono ${availableModels.length} modeli` : 'Brak połączenia z Ollama'}
            </p>
          </div>

          {/* Model Selection */}
          <div className="space-y-3">
            {/* Router Model */}
            <div>
              <label className="text-xs text-gray-400 mb-1 block">
                🎯 Router Model
              </label>
              <select
                value={tempSettings.routerModel}
                onChange={(e) => handleModelChange('router', e.target.value)}
                className="w-full px-3 py-2 bg-[#3c3c3c] border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent cursor-pointer"
              >
                {availableModels.length > 0 ? (
                  availableModels.map(model => (
                    <option key={model} value={model}>{model}</option>
                  ))
                ) : (
                  <option value={tempSettings.routerModel}>{tempSettings.routerModel}</option>
                )}
              </select>
              <p className="text-xs text-gray-500 mt-1">Szybki model do analizy (~3B)</p>
            </div>

            {/* Planner Model */}
            <div>
              <label className="text-xs text-gray-400 mb-1 block">
                🧠 Planner Model
              </label>
              <select
                value={tempSettings.plannerModel}
                onChange={(e) => handleModelChange('planner', e.target.value)}
                className="w-full px-3 py-2 bg-[#3c3c3c] border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent cursor-pointer"
              >
                {availableModels.length > 0 ? (
                  availableModels.map(model => (
                    <option key={model} value={model}>{model}</option>
                  ))
                ) : (
                  <option value={tempSettings.plannerModel}>{tempSettings.plannerModel}</option>
                )}
              </select>
              <p className="text-xs text-gray-500 mt-1">Strategiczny model (~14B)</p>
            </div>

            {/* Coder Model */}
            <div>
              <label className="text-xs text-gray-400 mb-1 block">
                💻 Coder Model
              </label>
              <select
                value={tempSettings.coderModel}
                onChange={(e) => handleModelChange('coder', e.target.value)}
                className="w-full px-3 py-2 bg-[#3c3c3c] border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent cursor-pointer"
              >
                {availableModels.length > 0 ? (
                  availableModels.map(model => (
                    <option key={model} value={model}>{model}</option>
                  ))
                ) : (
                  <option value={tempSettings.coderModel}>{tempSettings.coderModel}</option>
                )}
              </select>
              <p className="text-xs text-gray-500 mt-1">Specjalista kodowania (~7B)</p>
            </div>
          </div>

          {/* Save Button */}
          <div className="pt-2 border-t border-gray-700">
            <button
              onClick={handleSaveSettings}
              className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <i className="ri-save-line"></i>
              Zapisz konfigurację modeli
            </button>
            {showSaveSuccess && (
              <div className="mt-2 px-3 py-2 bg-green-900/30 border border-green-700/50 rounded-md text-xs text-green-400 flex items-center gap-2">
                <i className="ri-checkbox-circle-line"></i>
                Konfiguracja zapisana! Modele będą pamiętane po odświeżeniu.
              </div>
            )}
          </div>

          {/* Quick Commands */}
          {!ollamaConnected && (
            <div className="text-xs text-gray-400 bg-yellow-900/20 border border-yellow-700/50 rounded-md p-2">
              <div className="font-medium text-yellow-400 mb-1">⚠️ Ollama nie jest dostępna</div>
              <div className="space-y-1">
                <div>1. Uruchom: <code className="text-blue-400 bg-[#1e1e1e] px-1 rounded">ollama serve</code></div>
                <div>2. Pobierz modele:</div>
                <div className="ml-3">
                  <code className="text-blue-400 bg-[#1e1e1e] px-1 rounded">ollama pull qwen2.5:3b</code>
                </div>
                <div className="ml-3">
                  <code className="text-blue-400 bg-[#1e1e1e] px-1 rounded">ollama pull qwen2.5:14b</code>
                </div>
                <div className="ml-3">
                  <code className="text-blue-400 bg-[#1e1e1e] px-1 rounded">ollama pull deepseek-coder:6.7b</code>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Agents Status */}
      <div className="flex-shrink-0 px-4 py-3 border-b border-gray-700 bg-[#252526]">
        <div className="space-y-2">
          {agents.map(agent => (
            <div key={agent.id} className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-2 h-2 rounded-full ${getAgentStatusColor(agent.status)} ${agent.status === 'active' ? 'animate-pulse' : ''}`}></div>
                <span className="text-sm font-medium text-gray-200">{agent.name}</span>
                <span className="text-xs text-gray-500">{agent.model}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-gray-400">{getAgentStatusText(agent.status)}</span>
                <span className="text-xs text-gray-500">{agent.vram}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Task Queue */}
      {tasks.length > 0 && (
        <div className="flex-shrink-0 px-4 py-3 border-b border-gray-700 bg-[#252526]">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-gray-200">📋 Kolejka zadań</h3>
            <div className="flex items-center gap-3 text-xs">
              <span className="text-gray-400">Oczekuje: {pendingTasks.length}</span>
              <span className="text-blue-400">W trakcie: {inProgressTasks.length}</span>
              <span className="text-green-400">Ukończone: {completedTasks.length}</span>
              {failedTasks.length > 0 && (
                <span className="text-red-400">Błędy: {failedTasks.length}</span>
              )}
            </div>
          </div>
          
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {tasks.slice(-5).reverse().map(task => (
              <div key={task.id} className="bg-[#2d2d30] rounded-md p-2 border border-gray-700">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <span className="text-sm flex-shrink-0">{getTaskStatusIcon(task.status)}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-gray-200 truncate">{task.title}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium whitespace-nowrap ${getPriorityColor(task.priority)}`}>
                          {getPriorityText(task.priority)}
                        </span>
                      </div>
                      <p className="text-xs text-gray-400 line-clamp-2">{task.description}</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500 whitespace-nowrap flex-shrink-0">
                    {getTaskStatusText(task.status)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Chat Messages - tylko konwersacja */}
      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {chatMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <i className="ri-robot-2-line text-6xl text-gray-600 mb-4"></i>
            <h3 className="text-lg font-bold text-gray-200 mb-2">Multi-Agent AI System</h3>
            <p className="text-sm text-gray-400 max-w-md mb-4">
              System 3 agentów AI pracujących razem:
            </p>
            <div className="space-y-2 text-left max-w-md">
              <div className="flex items-start gap-2">
                <span className="text-lg">🎯</span>
                <div>
                  <p className="text-sm font-medium text-gray-200">Router ({settings.routerModel})</p>
                  <p className="text-xs text-gray-400">Klasyfikuje zapytania i kieruje do właściwego agenta</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-lg">🧠</span>
                <div>
                  <p className="text-sm font-medium text-gray-200">Planner ({settings.plannerModel})</p>
                  <p className="text-xs text-gray-400">Rozbija złożone zadania na konkretne kroki</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-lg">💻</span>
                <div>
                  <p className="text-sm font-medium text-gray-200">Coder ({settings.coderModel})</p>
                  <p className="text-xs text-gray-400">Wykonuje zadania kodowania</p>
                </div>
              </div>
            </div>
            {!ollamaConnected && (
              <div className="mt-4 text-xs text-red-400 bg-red-900/20 border border-red-700/50 rounded-md p-2">
                ⚠️ Brak połączenia z Ollama - kliknij <i className="ri-settings-3-line"></i> aby skonfigurować
              </div>
            )}
          </div>
        ) : (
          <>
            {chatMessages.map(message => {
              const isUser = message.agent === 'system' && message.content.includes('Przetwarzam:');
              const displayContent = isUser ? message.content.replace('Przetwarzam: "', '').replace('"', '') : message.content;
              
              return (
                <div
                  key={message.id}
                  className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-4 py-3 ${
                      isUser
                        ? 'bg-[#0e639c] text-white'
                        : 'bg-[#2d2d30] text-gray-200'
                    }`}
                  >
                    {!isUser && (
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-lg">{getAgentIcon(message.agent)}</span>
                        <span className="text-sm font-bold">{getAgentName(message.agent)}</span>
                      </div>
                    )}
                    <p className="text-sm whitespace-pre-wrap break-words">{displayContent}</p>
                    <div className="text-xs opacity-60 mt-2">
                      {message.timestamp.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Active Model Monitor */}
      {activeAgent && (
        <div className="flex-shrink-0 px-4 py-2 border-t border-gray-700 bg-[#252526]">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-xs font-medium text-gray-400">Aktywny model:</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">{getAgentIcon(activeAgent.role)}</span>
              <span className="text-sm font-bold text-gray-200">{activeAgent.name}</span>
              <span className="text-xs text-purple-400">→</span>
              <span className="text-xs text-gray-300 font-mono">{activeAgent.model}</span>
            </div>
            <div className="flex-1"></div>
            <span className="text-xs text-gray-500">{activeAgent.vram}</span>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="flex-shrink-0 border-t border-gray-700 bg-[#1e1e1e]">
        <form onSubmit={handleSubmit} className="p-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder={ollamaConnected ? "Zadaj pytanie lub opisz zadanie..." : "Połącz się z Ollama aby rozpocząć..."}
              className="flex-1 px-4 py-2 text-sm bg-[#3c3c3c] border border-gray-600 text-gray-200 placeholder-gray-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent disabled:bg-[#2d2d30] disabled:cursor-not-allowed"
              disabled={isProcessing || !ollamaConnected}
            />
            <button
              type="submit"
              disabled={!userInput.trim() || isProcessing || !ollamaConnected}
              className="px-6 py-2 text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 disabled:bg-gray-700 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              {isProcessing ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Przetwarzam...
                </>
              ) : (
                <>
                  <i className="ri-send-plane-fill mr-2"></i>
                  Wyślij
                </>
              )}
            </button>
          </div>
          
          {isProcessing && (
            <div className="mt-2 flex items-center gap-2 text-xs text-gray-400">
              <i className="ri-information-line"></i>
              <span>Sprawdź terminal aby zobaczyć co robi agent...</span>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
