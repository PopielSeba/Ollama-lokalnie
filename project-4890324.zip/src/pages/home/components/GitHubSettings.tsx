import { useState, useEffect } from 'react';

interface GitHubSettingsProps {
  onClose: () => void;
}

interface GitHubConfig {
  token: string;
  repoUrl: string;
  branch: string;
  autoSync: boolean;
  syncInterval: number;
}

export default function GitHubSettings({ onClose }: GitHubSettingsProps) {
  const [config, setConfig] = useState<GitHubConfig>({
    token: '',
    repoUrl: '',
    branch: 'main',
    autoSync: true,
    syncInterval: 5,
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [repoInfo, setRepoInfo] = useState<any>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    // Wczytaj zapisaną konfigurację
    const saved = localStorage.getItem('github-config');
    if (saved) {
      const parsed = JSON.parse(saved);
      setConfig(parsed);
      if (parsed.token && parsed.repoUrl) {
        setIsConnected(true);
        verifyConnection(parsed);
      }
    }
  }, []);

  const verifyConnection = async (cfg: GitHubConfig) => {
    try {
      const urlParts = cfg.repoUrl.replace('https://github.com/', '').split('/');
      const repoOwner = urlParts[0];
      const repoName = urlParts[1]?.replace('.git', '');

      const response = await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/github-sync`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'get-repo-info',
            repoOwner,
            repoName,
            githubToken: cfg.token,
          }),
        }
      );

      const data = await response.json();
      if (data.success) {
        setRepoInfo(data.data);
        setConfig(prev => ({ ...prev, branch: data.data.defaultBranch }));
      }
    } catch (error) {
      console.error('Błąd weryfikacji:', error);
    }
  };

  const testConnection = async () => {
    if (!config.token.trim() || !config.repoUrl.trim()) {
      setMessage({
        type: 'error',
        text: 'Wypełnij token i URL repozytorium',
      });
      return;
    }

    setIsSaving(true);
    setMessage(null);

    try {
      // Parse repository URL
      const match = config.repoUrl.match(/github\.com\/([^\/]+)\/([^\/]+)/);
      if (!match) {
        throw new Error('Nieprawidłowy format URL. Użyj: https://github.com/username/repo');
      }

      const [, owner, repo] = match;
      const cleanRepo = repo.replace(/\.git$/, '');

      console.log('Testing connection:', { owner, repo: cleanRepo, tokenLength: config.token.length });

      // Test direct GitHub API call first (without Edge Function)
      const directResponse = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}`,
        {
          headers: {
            'Authorization': `Bearer ${config.token}`,
            'Accept': 'application/vnd.github.v3+json',
          }
        }
      );

      console.log('Direct API response:', directResponse.status, directResponse.statusText);

      if (!directResponse.ok) {
        const errorData = await directResponse.json().catch(() => ({}));
        console.error('Direct API error:', errorData);
        
        if (directResponse.status === 401) {
          throw new Error('Token jest nieprawidłowy lub wygasł. Wygeneruj nowy token.');
        } else if (directResponse.status === 404) {
          throw new Error(`Repozytorium ${owner}/${cleanRepo} nie zostało znalezione. Sprawdź URL.`);
        } else if (directResponse.status === 403) {
          throw new Error('Token nie ma wystarczających uprawnień. Upewnij się że ma scope "repo".');
        } else {
          throw new Error(`GitHub API error: ${directResponse.status} - ${errorData.message || directResponse.statusText}`);
        }
      }

      const repoData = await directResponse.json();
      console.log('Repository data:', repoData);

      setMessage({
        type: 'success',
        text: `✅ Połączenie udane!\n\nRepozytorium: ${repoData.full_name}\nGałąź domyślna: ${repoData.default_branch}\nStatus: ${repoData.private ? 'Prywatne' : 'Publiczne'}`
      });

      // Update branch if not set
      if (!config.branch && repoData.default_branch) {
        setConfig(prev => ({ ...prev, branch: repoData.default_branch }));
      }

    } catch (error) {
      console.error('Connection test error:', error);
      setMessage({
        type: 'error',
        text: error instanceof Error ? error.message : 'Nieznany błąd podczas testowania połączenia',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setMessage(null);

    try {
      // Walidacja - sprawdź czy pola są wypełnione
      if (!config.token.trim() || !config.repoUrl.trim()) {
        setMessage({
          type: 'error',
          text: '❌ Token i URL repozytorium są wymagane'
        });
        setIsSaving(false);
        return;
      }

      // Sprawdź połączenie
      const urlParts = config.repoUrl.replace('https://github.com/', '').split('/');
      const repoOwner = urlParts[0];
      const repoName = urlParts[1]?.replace('.git', '');

      if (!repoOwner || !repoName) {
        setMessage({
          type: 'error',
          text: '❌ Nieprawidłowy URL repozytorium. Użyj formatu: https://github.com/username/repo'
        });
        setIsSaving(false);
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/github-sync`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'get-repo-info',
            repoOwner,
            repoName,
            githubToken: config.token,
          }),
        }
      );

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Nie można połączyć z repozytorium');
      }

      // Zapisz konfigurację
      localStorage.setItem('github-config', JSON.stringify(config));
      setRepoInfo(data.data);
      setIsConnected(true);
      setMessage({ type: 'success', text: '✅ Połączono z GitHub!' });

      // Po udanym połączeniu, pobierz pliki z repozytorium
      if (data?.success) {
        setIsSaving(true);
        await importFilesFromGitHub(config.repoUrl, config.branch, config.token);
        setIsSaving(false);
      }

      // Uruchom synchronizację
      if (config.autoSync) {
        window.dispatchEvent(new CustomEvent('github-sync-enabled', { detail: config }));
      }

      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (error: any) {
      setMessage({ type: 'error', text: `❌ ${error.message}` });
    } finally {
      setIsSaving(false);
    }
  };

  const importFilesFromGitHub = async (repoUrl: string, branch: string, token: string) => {
    try {
      const match = repoUrl.match(/github\.com\/([^\/]+)\/([^\/]+)/);
      if (!match) return;

      const [, owner, repo] = match;
      const cleanRepo = repo.replace(/\.git$/, '');

      // Pobierz strukturę repozytorium
      const treeResponse = await fetch(
        `https://api.github.com/repos/${owner}/${cleanRepo}/git/trees/${branch}?recursive=1`,
        {
          headers: {
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/vnd.github.v3+json'
          }
        }
      );

      if (!treeResponse.ok) {
        console.error('Nie można pobrać struktury repozytorium');
        return;
      }

      const data = await treeResponse.json();
      
      // Filtruj tylko pliki (nie foldery)
      const fileItems = data.tree.filter((item: any) => 
        item.type === 'blob' && 
        !item.path.includes('node_modules') &&
        !item.path.includes('.git/') &&
        item.size < 1000000 // Pomiń pliki większe niż 1MB
      );

      const newFiles: any[] = [];

      // Pobierz zawartość plików (max 100 plików)
      const filesToFetch = fileItems.slice(0, 100);
      
      for (const file of filesToFetch) {
        try {
          // Use GitHub API for private repos
          const response = await fetch(
            `https://api.github.com/repos/${owner}/${cleanRepo}/contents/${file.path}?ref=${branch}`,
            {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/vnd.github.v3+json'
              }
            }
          );

          if (response.ok) {
            const fileData = await response.json();
            // Decode base64 content
            const content = atob(fileData.content.replace(/\n/g, ''));
            
            newFiles.push({
              id: file.sha,
              name: file.path.split('/').pop() || file.path,
              path: file.path,
              type: 'file',
              content
            });
          }
        } catch (error) {
          console.error(`Błąd pobierania pliku ${file.path}:`, error);
        }
      }

      // Zapisz pliki do localStorage
      if (newFiles.length > 0) {
        localStorage.setItem('editor_files', JSON.stringify(newFiles));
        
        // Wyślij event żeby odświeżyć listę plików
        window.dispatchEvent(new CustomEvent('github-files-imported', {
          detail: { files: newFiles }
        }));

        console.log(`✅ Zaimportowano ${newFiles.length} plików z GitHub`);
      }

    } catch (error) {
      console.error('Błąd importu plików:', error);
    }
  };

  const handleDisconnect = () => {
    localStorage.removeItem('github-config');
    setConfig({
      token: '',
      repoUrl: '',
      branch: 'main',
      autoSync: true,
      syncInterval: 5,
    });
    setIsConnected(false);
    setRepoInfo(null);
    setMessage({ type: 'success', text: '✅ Rozłączono z GitHub' });
    window.dispatchEvent(new CustomEvent('github-sync-disabled'));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <i className="ri-github-fill text-2xl"></i>
            <h2 className="text-xl font-semibold">Synchronizacja z GitHub</h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center hover:bg-gray-100 rounded-lg transition-colors"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <div className="p-6 space-y-6">
          {isConnected && repoInfo && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <i className="ri-checkbox-circle-fill text-green-600 text-xl mt-0.5"></i>
                <div className="flex-1">
                  <h3 className="font-semibold text-green-900">Połączono z repozytorium</h3>
                  <p className="text-sm text-green-700 mt-1">{repoInfo.fullName}</p>
                  {repoInfo.description && (
                    <p className="text-sm text-green-600 mt-1">{repoInfo.description}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2 text-xs text-green-600">
                    <span className="flex items-center gap-1">
                      <i className="ri-git-branch-line"></i>
                      {repoInfo.defaultBranch}
                    </span>
                    <span className="flex items-center gap-1">
                      {repoInfo.private ? (
                        <>
                          <i className="ri-lock-line"></i>
                          Prywatne
                        </>
                      ) : (
                        <>
                          <i className="ri-global-line"></i>
                          Publiczne
                        </>
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {message && (
            <div
              className={`rounded-lg p-4 ${
                message.type === 'success'
                  ? 'bg-green-50 border border-green-200 text-green-800'
                  : 'bg-red-50 border border-red-200 text-red-800'
              }`}
            >
              {message.text}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Personal Access Token
              </label>
              <input
                type="password"
                value={config.token}
                onChange={(e) => setConfig({ ...config, token: e.target.value })}
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
              <p className="text-xs text-gray-500 mt-1.5">
                <a
                  href="https://github.com/settings/tokens/new?scopes=repo"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  Wygeneruj token
                </a>{' '}
                z uprawnieniami <code className="bg-gray-100 px-1 rounded">repo</code>
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                URL Repozytorium
              </label>
              <input
                type="text"
                value={config.repoUrl}
                onChange={(e) => setConfig({ ...config, repoUrl: e.target.value })}
                placeholder="https://github.com/username/repository"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Gałąź (Branch)
              </label>
              <input
                type="text"
                value={config.branch}
                onChange={(e) => setConfig({ ...config, branch: e.target.value })}
                placeholder="main"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>

            <div className="border-t border-gray-200 pt-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-900">Automatyczna synchronizacja</h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Zapisuj zmiany na GitHub automatycznie
                  </p>
                </div>
                <button
                  onClick={() => setConfig({ ...config, autoSync: !config.autoSync })}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    config.autoSync ? 'bg-blue-600' : 'bg-gray-300'
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                      config.autoSync ? 'translate-x-6' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {config.autoSync && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Interwał synchronizacji (minuty)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={config.syncInterval}
                    onChange={(e) =>
                      setConfig({ ...config, syncInterval: parseInt(e.target.value) || 5 })
                    }
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t border-gray-200">
            {isConnected && (
              <button
                onClick={handleDisconnect}
                className="px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors whitespace-nowrap"
              >
                Rozłącz
              </button>
            )}
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors whitespace-nowrap"
            >
              Anuluj
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1 px-4 py-2.5 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {isSaving ? 'Łączenie...' : 'Zapisz i połącz'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
