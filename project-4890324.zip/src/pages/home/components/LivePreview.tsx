
import { useEffect, useRef, useState } from 'react';

interface LivePreviewProps {
  htmlContent: string;
}

export default function LivePreview({ htmlContent }: LivePreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [viewMode, setViewMode] = useState<'visual' | 'code'>('visual');

  useEffect(() => {
    if (iframeRef.current && viewMode === 'visual') {
      const iframe = iframeRef.current;
      const doc = iframe.contentDocument || iframe.contentWindow?.document;
      
      if (doc) {
        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <style>
                body { margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
              </style>
            </head>
            <body>
              ${htmlContent}
            </body>
          </html>
        `);
        doc.close();
      }
    }
  }, [htmlContent, viewMode]);

  return (
    <div className="h-full flex flex-col bg-[#1e1e1e]">
      <div className="h-10 bg-[#2d2d30] border-b border-gray-700 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <i className="ri-eye-line text-gray-400"></i>
          <span className="text-sm text-gray-300">Podgląd na żywo</span>
        </div>
        
        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 bg-[#1e1e1e] rounded p-1">
          <button
            onClick={() => setViewMode('visual')}
            className={`px-3 py-1 rounded text-xs whitespace-nowrap transition-colors cursor-pointer ${
              viewMode === 'visual'
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            title="Podgląd wizualny"
          >
            <i className="ri-layout-line mr-1"></i>
            Wizualny
          </button>
          <button
            onClick={() => setViewMode('code')}
            className={`px-3 py-1 rounded text-xs whitespace-nowrap transition-colors cursor-pointer ${
              viewMode === 'code'
                ? 'bg-blue-600 text-white'
                : 'text-gray-400 hover:text-gray-200'
            }`}
            title="Kod HTML"
          >
            <i className="ri-code-line mr-1"></i>
            Kod
          </button>
        </div>
      </div>
      
      <div className="flex-1 bg-white overflow-hidden">
        {viewMode === 'visual' ? (
          <iframe
            ref={iframeRef}
            className="w-full h-full border-0"
            title="Live Preview"
          />
        ) : (
          <div className="w-full h-full overflow-auto bg-[#1e1e1e] p-4">
            <pre className="text-sm text-gray-300 font-mono">
              <code>{htmlContent}</code>
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
