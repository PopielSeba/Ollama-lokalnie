import { useState, useRef, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import type { ChatMessage, WorkspaceSettings } from '../../../hooks/useWorkspace';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Action {
  type: 'create_file' | 'edit_file' | 'delete_file' | 'install_package' | 'run_command';
  path?: string;
  content?: string;
  package?: string;
  command?: string;
  status?: 'pending' | 'approved' | 'rejected' | 'executed';
}

interface ChatPanelProps {
  onTerminalOutput: (text: string) => void;
  files: any[];
  onFilesChange: (files: any[]) => void;
  onFileSelect: (fileId: string) => void;
  messages: ChatMessage[];
  onMessagesChange: (messages: ChatMessage[]) => void;
  settings: WorkspaceSettings;
  onSettingsChange: (settings: WorkspaceSettings) => void;
}

// 🎯 Dodaję brakujący typ WorkspaceFile
interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  content?: string;
  parentPath?: string | null;
}

export default function ChatPanel({ 
  onTerminalOutput, 
  files, 
  onFilesChange, 
  onFileSelect,
  messages,
  onMessagesChange,
  settings,
  onSettingsChange
}: ChatPanelProps) {
  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [isLoadingModels, setIsLoadingModels] = useState(false);
  const [ollamaConnected, setOllamaConnected] = useState(false);
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Test Ollama connection and load models on mount
  useEffect(() => {
    testOllamaConnection();
  }, [settings.ollamaUrl]);

  const testOllamaConnection = async () => {
    setIsTestingConnection(true);
    try {
      const response = await fetch(`${settings.ollamaUrl}/api/tags`, {
        method: 'GET',
      });

      if (response.ok) {
        const data = await response.json();
        const models = data.models?.map((m: any) => m.name) || [];
        setAvailableModels(models);
        setOllamaConnected(true);
        
        // Set first model as default if current model is not available
        if (models.length > 0 && !models.includes(settings.selectedModel)) {
          onSettingsChange({ ...settings, selectedModel: models[0] });
        }
        
        onTerminalOutput(`✅ Połączono z Ollama (${settings.ollamaUrl}) - znaleziono ${models.length} modeli`);
      } else {
        setOllamaConnected(false);
        setAvailableModels([]);
        onTerminalOutput(`⚠️ Nie można połączyć z Ollama pod adresem ${settings.ollamaUrl}. Sprawdź czy Ollama jest uruchomiona (ollama serve)`);
      }
    } catch (error) {
      setOllamaConnected(false);
      setAvailableModels([]);
      onTerminalOutput(`❌ Ollama nie jest dostępna pod adresem ${settings.ollamaUrl}. Sprawdź adres i upewnij się, że Ollama działa.`);
    } finally {
      setIsTestingConnection(false);
    }
  };

  const loadAvailableModels = async () => {
    setIsLoadingModels(true);
    try {
      const response = await fetch(`${settings.ollamaUrl}/api/tags`, {
        method: 'GET',
      });

      if (!response.ok) {
        throw new Error('Nie można pobrać listy modeli');
      }

      const data = await response.json();
      const models = data.models?.map((m: any) => m.name) || [];
      
      setAvailableModels(models);
      setOllamaConnected(true);
      
      if (models.length === 0) {
        onTerminalOutput(`⚠️ Brak zainstalowanych modeli. Pobierz model: ollama pull deepseek-coder:6.7b`);
      } else {
        onTerminalOutput(`✅ Znaleziono ${models.length} zainstalowanych modeli`);
      }
    } catch (error) {
      setOllamaConnected(false);
      onTerminalOutput(`❌ Błąd: ${error instanceof Error ? error.message : 'Nie można połączyć z Ollama'}`);
    } finally {
      setIsLoadingModels(false);
    }
  };

  const executeAction = async (messageId: string, actionIndex: number) => {
    const message = messages.find(m => m.id === messageId);
    if (!message || !message.actions) return;

    const action = message.actions[actionIndex];
    
    // Update action status to executing
    onMessagesChange(messages.map(m => {
      if (m.id === messageId && m.actions) {
        const newActions = [...m.actions];
        newActions[actionIndex] = { ...action, status: 'approved' };
        return { ...m, actions: newActions };
      }
      return m;
    }));

    onTerminalOutput(`🔄 Wykonuję: ${action.type} ${action.path || action.package || action.command || ''}`);

    try {
      switch (action.type) {
        case 'create_file': {
          if (!action.path || !action.content) break;
          
          const pathParts = action.path.split('/');
          const fileName = pathParts[pathParts.length - 1];
          const parentPath = pathParts.slice(0, -1).join('/');
          
          const newFile = {
            id: `file-${Date.now()}`,
            name: fileName,
            path: action.path,
            parentPath: parentPath || null,
            type: 'file',
            content: action.content
          };
          
          onFilesChange([...files, newFile]);
          onFileSelect(newFile.id);
          onTerminalOutput(`✅ Utworzono plik: ${action.path}`);
          break;
        }

        case 'edit_file': {
          if (!action.path || !action.content) break;
          
          const fileToEdit = files.find(f => f.path === action.path);
          if (fileToEdit) {
            const updatedFiles = files.map(f => 
              f.path === action.path ? { ...f, content: action.content } : f
            );
            onFilesChange(updatedFiles);
            onFileSelect(fileToEdit.id);
            onTerminalOutput(`✅ Zaktualizowano plik: ${action.path}`);
          } else {
            onTerminalOutput(`⚠️ Plik nie znaleziony: ${action.path}`);
          }
          break;
        }

        case 'delete_file': {
          if (!action.path) break;
          
          const updatedFiles = files.filter(f => f.path !== action.path);
          onFilesChange(updatedFiles);
          onTerminalOutput(`✅ Usunięto plik: ${action.path}`);
          break;
        }

        case 'install_package': {
          if (!action.package) break;
          onTerminalOutput(`📦 Instalacja pakietu: ${action.package}`);
          onTerminalOutput(`⚠️ Uwaga: Instalacja pakietów wymaga ręcznego uruchomienia: npm install ${action.package}`);
          break;
        }

        case 'run_command': {
          if (!action.command) break;
          onTerminalOutput(`⚡ Komenda: ${action.command}`);
          onTerminalOutput(`⚠️ Uwaga: Komendy wymagają ręcznego uruchomienia w terminalu`);
          break;
        }
      }

      // Mark as executed
      onMessagesChange(messages.map(m => {
        if (m.id === messageId && m.actions) {
          const newActions = [...m.actions];
          newActions[actionIndex] = { ...action, status: 'executed' };
          return { ...m, actions: newActions };
        }
        return m;
      }));

    } catch (error) {
      onTerminalOutput(`❌ Błąd wykonania: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
    }
  };

  const rejectAction = (messageId: string, actionIndex: number) => {
    onMessagesChange(messages.map(m => {
      if (m.id === messageId && m.actions) {
        const newActions = [...m.actions];
        newActions[actionIndex] = { ...newActions[actionIndex], status: 'rejected' };
        return { ...m, actions: newActions };
      }
      return m;
    }));
    onTerminalOutput(`❌ Odrzucono akcję`);
  };

  const handleSend = async () => {
    if (!input.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    onMessagesChange([...messages, userMessage]);
    const userInput = input;
    setInput('');
    setIsGenerating(true);

    onTerminalOutput(`💬 Wysyłam zapytanie do ${settings.aiProvider === 'ollama' ? 'Ollama' : 'GPT-4'}...`);

    try {
      // 🎯 RAG: Build context BEFORE sending to AI
      onTerminalOutput(`\n🚀 Rozpoczynam przetwarzanie zapytania: "${userInput}"\n`);
      
      const projectContext = buildProjectContext(userInput);
      const relevantFilesCount = findRelevantFiles(userInput).length;
      
      onTerminalOutput(`📦 Kontekst projektu gotowy (${relevantFilesCount} plików)`);
      
      if (settings.aiProvider === 'ollama') {
        // Use local Ollama WITH RAG CONTEXT
        await handleOllamaRequestWithRAG(userInput, projectContext);
      } else {
        // Use OpenAI via Supabase WITH RAG CONTEXT
        await handleOpenAIRequestWithRAG(userInput, projectContext);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      onTerminalOutput(`❌ Błąd: ${errorMessage}`);
      
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `❌ Przepraszam, wystąpił błąd podczas komunikacji z AI:\n\n${errorMessage}\n\n${
          settings.aiProvider === 'ollama' 
            ? 'Sprawdź czy:\n1. Ollama jest uruchomiona (ollama serve)\n2. Model jest pobrany (ollama pull ' + settings.selectedModel + ')\n3. Ollama działa na ' + settings.ollamaUrl
            : 'Sprawdź czy:\n1. Klucz OpenAI API jest poprawnie skonfigurowany w Supabase\n2. Masz połączenie z internetem\n3. Supabase Edge Function działa poprawnie'
        }`,
        timestamp: new Date()
      };
      onMessagesChange([...messages, userMessage, errorMsg]);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleOllamaRequestWithRAG = async (userInput: string, projectContext: string) => {
    onTerminalOutput(`⚙️ Wysyłam zapytanie do Ollama (${settings.selectedModel}) z pełnym kontekstem projektu...`);
    onTerminalOutput(`📏 Długość kontekstu: ${projectContext.length} znaków`);
    
    // Build full prompt with roles and RAG context
    const fullPrompt = `${getSystemPrompt()}

${getDeveloperPrompt()}

${projectContext}

---

👤 PYTANIE UŻYTKOWNIKA:
${userInput}

---

⚠️ PAMIĘTAJ: Zwróć TYLKO czysty JSON bez markdown!`;

    onTerminalOutput(`📤 Wysyłam prompt (${fullPrompt.length} znaków) do Ollama...`);

    const response = await fetch(`${settings.ollamaUrl}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: settings.selectedModel,
        messages: [
          { role: 'system', content: getSystemPrompt() },
          { role: 'user', content: `${projectContext}\n\n---\n\n👤 PYTANIE:\n${userInput}` }
        ],
        stream: false,
        format: 'json',
        options: {
          temperature: 0.7,
          num_predict: 2000
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama error: ${response.status}`);
    }

    const data = await response.json();
    let assistantMessage = data.message?.content || data.response;

    // Clean up response - remove markdown code blocks if present
    assistantMessage = assistantMessage.replace(/^```json\s*/i, '').replace(/\s*```$/, '').trim();

    // Try to parse JSON with actions
    let parsedResponse;
    try {
      parsedResponse = JSON.parse(assistantMessage);
    } catch (parseError) {
      console.error('JSON Parse Error:', parseError);
      console.log('Raw response:', assistantMessage);
      
      // If not JSON, return plain response
      parsedResponse = {
        message: assistantMessage,
        actions: []
      };
    }

    // Generate unique IDs for actions
    const actionsWithIds = parsedResponse.actions && Array.isArray(parsedResponse.actions)
      ? parsedResponse.actions.map((a: any, index: number) => ({
          ...a,
          id: `action-${Date.now()}-${index}`,
          status: 'pending' as const
        }))
      : undefined;

    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: parsedResponse.message || assistantMessage,
      timestamp: new Date(),
      actions: actionsWithIds
    };

    onMessagesChange([...messages, { id: Date.now().toString(), role: 'user', content: userInput, timestamp: new Date() }, aiMessage]);
    onTerminalOutput(`✅ Otrzymano odpowiedź od Ollama (${settings.selectedModel})`);

    if (aiMessage.actions && aiMessage.actions.length > 0) {
      onTerminalOutput(`📋 AI zaproponował ${aiMessage.actions.length} akcji do wykonania`);
    }
    
    onTerminalOutput(`\n✅ Przetwarzanie zakończone\n`);
  };

  const handleOpenAIRequestWithRAG = async (userInput: string, projectContext: string) => {
    onTerminalOutput('⚙️ Wysyłam zapytanie do GPT-4 z pełnym kontekstem projektu...');
    onTerminalOutput(`📏 Długość kontekstu: ${projectContext.length} znaków`);

    const conversationMessages = messages.map(m => ({
      role: m.role,
      content: m.content
    }));

    const { data, error } = await supabase.functions.invoke('ai-assistant', {
      body: {
        messages: [
          { role: 'system', content: getSystemPrompt() },
          { role: 'developer', content: getDeveloperPrompt() },
          ...conversationMessages,
          { role: 'user', content: `${projectContext}\n\n---\n\n👤 PYTANIE:\n${userInput}` }
        ],
        files: files.map(f => ({
          path: f.path,
          name: f.name,
          type: f.type,
          content: f.content
        })),
        projectStructure: files.map(f => ({
          path: f.path,
          type: f.type,
          size: f.content ? f.content.length : 0
        }))
      }
    });

    if (error) throw error;

    if (!data.success) {
      throw new Error(data.error || 'Nieznany błąd');
    }

    const response = data.response;
    
    let messageContent = '';
    let actions: Action[] = [];

    if (typeof response === 'string') {
      messageContent = response;
    } else if (response.message) {
      messageContent = response.message;
      if (response.actions && Array.isArray(response.actions)) {
        actions = response.actions.map((a: any) => ({
          ...a,
          status: 'pending' as const
        }));
      }
    }

    const aiMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: messageContent,
      timestamp: new Date(),
      actions: actions.length > 0 ? actions : undefined
    };

    onMessagesChange([...messages, { id: Date.now().toString(), role: 'user', content: userInput, timestamp: new Date() }, aiMessage]);
    onTerminalOutput(`✅ Otrzymano odpowiedź od GPT-4`);

    if (actions.length > 0) {
      onTerminalOutput(`📋 AI zaproponował ${actions.length} akcji do wykonania`);
    }
    
    onTerminalOutput(`\n✅ Przetwarzanie zakończone\n`);
  };

  // USUWAM STARĄ FUNKCJĘ handleOllamaRequest() - była bez RAG!
  // USUWAM STARĄ FUNKCJĘ handleOpenAIRequest() - była bez RAG!

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isGenerating) {
        handleSend();
      }
    }
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'create_file': return 'ri-file-add-line';
      case 'edit_file': return 'ri-file-edit-line';
      case 'delete_file': return 'ri-delete-bin-line';
      case 'install_package': return 'ri-download-line';
      case 'run_command': return 'ri-terminal-line';
      default: return 'ri-code-line';
    }
  };

  const getActionLabel = (type: string) => {
    switch (type) {
      case 'create_file': return 'Utwórz plik';
      case 'edit_file': return 'Edytuj plik';
      case 'delete_file': return 'Usuń plik';
      case 'install_package': return 'Zainstaluj pakiet';
      case 'run_command': return 'Uruchom komendę';
      default: return 'Akcja';
    }
  };

  const handleExecuteAction = async (action: any, messageIndex: number) => {
    try {
      setIsLoading(true);
      
      // Oznacz akcję jako wykonaną
      const updatedMessages = [...messages];
      if (updatedMessages[messageIndex] && updatedMessages[messageIndex].actions) {
        const actionIndex = updatedMessages[messageIndex].actions!.findIndex((a: any) => a.id === action.id);
        if (actionIndex !== -1) {
          updatedMessages[messageIndex].actions![actionIndex] = { ...action, executed: true };
          onMessagesChange(updatedMessages);
        }
      }

      // Wykonaj akcję
      onTerminalOutput(`🔄 Wykonuję: ${action.title || action.type}`);

      switch (action.type) {
        case 'create_file': {
          if (!action.path || !action.content) break;
          
          const pathParts = action.path.split('/');
          const fileName = pathParts[pathParts.length - 1];
          const parentPath = pathParts.slice(0, -1).join('/');
          
          const newFile = {
            id: `file-${Date.now()}`,
            name: fileName,
            path: action.path,
            parentPath: parentPath || null,
            type: 'file',
            content: action.content
          };
          
          onFilesChange([...files, newFile]);
          onFileSelect(newFile.id);
          onTerminalOutput(`✅ Utworzono plik: ${action.path}`);
          break;
        }

        case 'edit_file': {
          if (!action.path || !action.content) break;
          
          const fileToEdit = files.find(f => f.path === action.path);
          if (fileToEdit) {
            const updatedFiles = files.map(f => 
              f.path === action.path ? { ...f, content: action.content } : f
            );
            onFilesChange(updatedFiles);
            onFileSelect(fileToEdit.id);
            onTerminalOutput(`✅ Zaktualizowano plik: ${action.path}`);
          } else {
            onTerminalOutput(`⚠️ Plik nie znaleziony: ${action.path}`);
          }
          break;
        }

        case 'delete_file': {
          if (!action.path) break;
          
          const updatedFiles = files.filter(f => f.path !== action.path);
          onFilesChange(updatedFiles);
          onTerminalOutput(`✅ Usunięto plik: ${action.path}`);
          break;
        }
      }

      onTerminalOutput(`✅ Wykonano: ${action.title || action.type}`);
    } catch (error) {
      console.error('Błąd wykonywania akcji:', error);
      onTerminalOutput(`❌ Błąd wykonywania akcji: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRejectAction = (action: any, messageIndex: number) => {
    // Oznacz akcję jako odrzuconą
    const updatedMessages = [...messages];
    if (updatedMessages[messageIndex] && updatedMessages[messageIndex].actions) {
      const actionIndex = updatedMessages[messageIndex].actions.findIndex((a: any) => a.id === action.id);
      if (actionIndex !== -1) {
        updatedMessages[messageIndex].actions[actionIndex] = { ...action, rejected: true };
        onMessagesChange(updatedMessages);
      }
    }
    
    onTerminalOutput(`⏭️ Pominięto akcję: ${action.title}`);
  };

  // 🎯 RAG: Semantic search - find relevant files based on query
  const findRelevantFiles = (query: string, maxFiles: number = 10): WorkspaceFile[] => {
    const queryLower = query.toLowerCase();
    const keywords = queryLower.split(/\s+/).filter(k => k.length > 2);
    
    // 🔍 DEBUGOWANIE: Sprawdzam ile plików mamy w workspace
    onTerminalOutput(`🔍 Przeszukuję ${files.length} plików w workspace...`);
    
    // Score each file based on relevance
    const scoredFiles = files
      .filter(f => f.type === 'file' && f.content)
      .map(file => {
        let score = 0;
        const content = file.content?.toLowerCase() || '';
        const path = file.path.toLowerCase();
        const name = file.name.toLowerCase();
        
        // Exact phrase match in content (highest priority)
        if (content.includes(queryLower)) score += 100;
        
        // Keywords in filename (high priority)
        keywords.forEach(keyword => {
          if (name.includes(keyword)) score += 50;
          if (path.includes(keyword)) score += 30;
        });
        
        // Keywords in content
        keywords.forEach(keyword => {
          const matches = (content.match(new RegExp(keyword, 'g')) || []).length;
          score += matches * 10;
        });
        
        // Boost for common important files
        if (name.includes('config') || name.includes('price') || name.includes('plan')) score += 20;
        if (name.includes('landing') || name.includes('home') || name.includes('index')) score += 15;
        
        return { file, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, maxFiles);
    
    onTerminalOutput(`📊 Znaleziono ${scoredFiles.length} relewantnych plików (score > 0)`);
    
    return scoredFiles.map(item => item.file);
  };

  // 🎯 RAG: Build context from relevant files
  const buildProjectContext = (query: string): string => {
    const relevantFiles = findRelevantFiles(query, 10);
    
    if (relevantFiles.length === 0) {
      onTerminalOutput(`⚠️ Brak relewantnych plików dla zapytania`);
      
      // 🔍 Jeśli brak relewantnych, zwróć WSZYSTKIE pliki z workspace
      const allFiles = files.filter(f => f.type === 'file' && f.content);
      
      if (allFiles.length === 0) {
        return `📂 KONTEKST PROJEKTU: Brak plików w workspace.`;
      }
      
      onTerminalOutput(`📂 Używam wszystkich ${allFiles.length} plików z workspace`);
      
      const contextParts = allFiles.slice(0, 10).map(file => {
        const preview = file.content || '';
        return `📄 ${file.path}:\n\`\`\`\n${preview}\n\`\`\``;
      });
      
      return `📂 KONTEKST PROJEKTU (wszystkie pliki w workspace - ${allFiles.length} plików):\n\n${contextParts.join('\n\n---\n\n')}`;
    }
    
    onTerminalOutput(`✅ Buduję kontekst z ${relevantFiles.length} relewantnych plików`);
    
    const contextParts = relevantFiles.map(file => {
      const preview = file.content || '';
      return `📄 ${file.path}:\n\`\`\`\n${preview}\n\`\`\``;
    });
    
    return `📂 KONTEKST PROJEKTU (${relevantFiles.length} najbardziej relewantnych plików):\n\n${contextParts.join('\n\n---\n\n')}`;
  };

  // 🎯 System Prompt - Kim jest AI i jakie ma zasady
  const getSystemPrompt = (): string => {
    const projectName = files.find(f => f.name === 'package.json')?.content?.match(/"name":\s*"([^"]+)"/)?.[1] || 'Twój Projekt';
    
    return `Jesteś AI Pilotem projektu "${projectName}".

🎯 TWOJA ROLA:
- Masz pełny dostęp do plików projektu poprzez kontekst dostarczany przez system RAG
- Odpowiadasz WYŁĄCZNIE na podstawie dostarczonego kontekstu projektu
- Znasz ceny, treści, konfigurację, logikę biznesową - wszystko co jest w plikach
- Działasz jak Cursor/Lovable - znasz projekt od środka

⚠️ KRYTYCZNE ZASADY:
1. ZAWSZE odpowiadaj na podstawie PRAWDZIWYCH plików z kontekstu
2. Jeśli kontekst zawiera odpowiedź - cytuj konkretne pliki (ścieżka + fragment kodu)
3. Jeśli kontekstu brakuje - powiedz DOKŁADNIE czego brakuje i gdzie to powinno być
4. NIE UŻYWAJ fraz: "nie mam dostępu", "jako model językowy", "nie mogę pomóc"
5. Zwracaj TYLKO czysty JSON w formacie: {"message": "...", "actions": [...]}

📋 FORMAT ODPOWIEDZI:

**Dla pytań o projekt:**
{
  "message": "Znalazłem [informację] w pliku [ścieżka]:\\n\\n\`\`\`[język]\\n[kod z pliku]\\n\`\`\`\\n\\n(linia [numer])",
  "actions": []
}

**Gdy brak informacji:**
{
  "message": "Nie znalazłem [czego] w projekcie.\\n\\nPrzeszukałem:\\n- [lista plików]\\n\\nSprawdź czy [sugestia].",
  "actions": []
}

**Dla zadań edycji:**
{
  "message": "Wykonuję [co]...",
  "actions": [
    {
      "type": "edit_file",
      "path": "[ścieżka]",
      "content": "[nowa zawartość]",
      "description": "[opis zmiany]"
    }
  ]
}

🔍 DOSTĘPNE AKCJE:
- create_file: Tworzenie nowego pliku
- edit_file: Edycja istniejącego pliku
- delete_file: Usunięcie pliku
- install_package: Instalacja pakietu npm
- run_command: Uruchomienie komendy

💡 PRZYKŁADY POPRAWNYCH ODPOWIEDZI:

Pytanie: "Jakie ceny są w projekcie?"
✅ DOBRZE: "Znalazłem ceny w pliku src/config/pricing.ts:\\n\\n\`\`\`typescript\\nconst plans = [\\n  { name: 'Basic', price: 29 },\\n  { name: 'Pro', price: 99 }\\n]\\n\`\`\`\\n\\n(linie 5-8)"

❌ ŹLE: "Nie mam dostępu do projektu"
❌ ŹLE: "Jako model językowy nie mogę..."`;
  };

  // 🎯 Developer Prompt - Jak ma odpowiadać (styl, format)
  const getDeveloperPrompt = (): string => {
    return `🎨 STYL ODPOWIEDZI:
- Konkretnie i na temat
- Zawsze cytuj źródła (ścieżka pliku + numer linii)
- Używaj emoji dla czytelności (📄 plik, 💰 cena, ⚙️ config, ✅ sukces, ❌ błąd)
- Formatuj kod w blokach \`\`\`
- Jeśli coś nie istnieje - zaproponuj rozwiązanie

🔧 TECHNICZNE:
- Zawsze zwracaj TYLKO czysty JSON (bez markdown, bez \`\`\`json)
- Waliduj składnię JSON przed zwróceniem
- Używaj \\n dla nowych linii w stringach JSON
- Escapuj cudzysłowy w treści: \\"

📊 ANALIZA KONTEKSTU:
- Przeszukaj WSZYSTKIE dostarczone pliki
- Zwróć uwagę na: ceny, plany, features, konfigurację, copy marketingowy
- Jeśli pytanie dotyczy cen - szukaj w: pricing, plans, config, landing pages
- Jeśli pytanie dotyczy features - szukaj w: components, pages, config`;
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    const updatedMessages = [...messages, userMessage];
    onMessagesChange(updatedMessages);
    const userInput = input;
    setInput('');
    setIsLoading(true);

    try {
      // 🎯 RAG: Build context based on user query
      onTerminalOutput(`\n🚀 Rozpoczynam przetwarzanie zapytania: "${userInput}"\n`);
      
      const projectContext = buildProjectContext(userInput);
      const relevantFilesCount = findRelevantFiles(userInput).length;
      
      onTerminalOutput(`📦 Kontekst projektu gotowy (${relevantFilesCount} plików)`);
      
      if (settings.aiProvider === 'ollama') {
        // 🎯 Ollama with RAG context
        await handleOllamaRequestWithRAG(userInput, projectContext);
      } else {
        // 🎯 OpenAI with RAG context
        await handleOpenAIRequestWithRAG(userInput, projectContext);
      }

    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `❌ Błąd: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        timestamp: new Date(),
      };
      onMessagesChange([...updatedMessages, errorMessage]);
      onTerminalOutput(`❌ Błąd: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#1e1e1e]">
      <div className="h-10 bg-[#2d2d30] border-b border-gray-700 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <i className="ri-robot-2-line text-gray-400"></i>
          <span className="text-sm text-gray-300">
            AI Asystent ({settings.aiProvider === 'ollama' ? settings.selectedModel : 'GPT-4'})
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${settings.aiProvider === 'ollama' ? (ollamaConnected ? 'bg-blue-500' : 'bg-red-500') : 'bg-green-500'}`}></div>
            <span className="text-xs text-gray-400">
              {settings.aiProvider === 'ollama' ? (ollamaConnected ? 'Ollama' : 'Ollama (rozłączona)') : 'OpenAI'}
            </span>
          </div>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="text-gray-400 hover:text-gray-200 transition-colors cursor-pointer"
            title="Ustawienia AI"
          >
            <i className="ri-settings-3-line"></i>
          </button>
        </div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="bg-[#252526] border-b border-gray-700 p-3 space-y-3">
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Dostawca AI</label>
            <div className="flex gap-2">
              <button
                onClick={() => onSettingsChange({ ...settings, aiProvider: 'ollama' })}
                className={`flex-1 px-3 py-2 rounded text-sm transition-colors cursor-pointer ${
                  settings.aiProvider === 'ollama'
                    ? 'bg-blue-600 text-white'
                    : 'bg-[#2d2d30] text-gray-300 hover:bg-[#3e3e42]'
                }`}
              >
                <i className="ri-computer-line mr-1"></i>
                Ollama (Lokalnie)
              </button>
              <button
                onClick={() => onSettingsChange({ ...settings, aiProvider: 'openai' })}
                className={`flex-1 px-3 py-2 rounded text-sm transition-colors cursor-pointer ${
                  settings.aiProvider === 'openai'
                    ? 'bg-green-600 text-white'
                    : 'bg-[#2d2d30] text-gray-300 hover:bg-[#3e3e42]'
                }`}
              >
                <i className="ri-cloud-line mr-1"></i>
                GPT-4 (Cloud)
              </button>
            </div>
          </div>

          {settings.aiProvider === 'ollama' && (
            <div className="space-y-3">
              {/* Ollama URL Input */}
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Adres Ollama</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={settings.ollamaUrl}
                    onChange={(e) => onSettingsChange({ ...settings, ollamaUrl: e.target.value })}
                    placeholder="http://127.0.0.1:11434"
                    className="flex-1 px-3 py-2 bg-[#2d2d30] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-blue-500"
                  />
                  <button
                    onClick={testOllamaConnection}
                    disabled={isTestingConnection}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
                    title="Połącz z Ollama"
                  >
                    {isTestingConnection ? (
                      <i className="ri-loader-4-line animate-spin"></i>
                    ) : (
                      <i className="ri-link"></i>
                    )}
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  <i className="ri-information-line mr-1"></i>
                  Domyślnie: http://localhost:11434 lub http://127.0.0.1:11434
                </p>
              </div>

              {/* Connection Status & Test */}
              <div className="flex items-center justify-between p-2 bg-[#2d2d30] rounded">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${ollamaConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <span className="text-xs text-gray-300">
                    {ollamaConnected ? `Połączono z ${settings.ollamaUrl}` : 'Brak połączenia z Ollama'}
                  </span>
                </div>
                <button
                  onClick={testOllamaConnection}
                  disabled={isTestingConnection}
                  className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isTestingConnection ? (
                    <><i className="ri-loader-4-line animate-spin mr-1"></i>Testuję...</>
                  ) : (
                    <><i className="ri-refresh-line mr-1"></i>Test połączenia</>
                  )}
                </button>
              </div>

              {/* Model Selection */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-gray-400">Model Ollama</label>
                  <button
                    onClick={loadAvailableModels}
                    disabled={isLoadingModels}
                    className="text-xs text-blue-400 hover:text-blue-300 cursor-pointer disabled:opacity-50"
                  >
                    {isLoadingModels ? (
                      <><i className="ri-loader-4-line animate-spin mr-1"></i>Ładuję...</>
                    ) : (
                      <><i className="ri-refresh-line mr-1"></i>Odśwież listę</>
                    )}
                  </button>
                </div>
                
                {availableModels.length > 0 ? (
                  <select
                    value={settings.selectedModel}
                    onChange={(e) => onSettingsChange({ ...settings, selectedModel: e.target.value })}
                    className="w-full px-3 py-2 bg-[#2d2d30] border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:border-blue-500 cursor-pointer"
                  >
                    {availableModels.map(model => (
                      <option key={model} value={model}>{model}</option>
                    ))}
                  </select>
                ) : (
                  <div className="w-full px-3 py-2 bg-[#2d2d30] border border-gray-600 rounded text-sm text-gray-400">
                    {ollamaConnected ? 'Brak zainstalowanych modeli' : 'Połącz z Ollama aby zobaczyć modele'}
                  </div>
                )}
                
                <div className="mt-2 p-2 bg-[#2d2d30] rounded">
                  <p className="text-xs text-gray-400 mb-1">
                    <i className="ri-information-line mr-1"></i>
                    {availableModels.length > 0 
                      ? `Znaleziono ${availableModels.length} zainstalowanych modeli`
                      : 'Aby pobrać model, użyj:'
                    }
                  </p>
                  {availableModels.length === 0 && (
                    <code className="text-xs text-blue-400 block mt-1">
                      ollama pull deepseek-coder:6.7b
                    </code>
                  )}
                </div>
              </div>

              {/* Quick Commands */}
              <div className="text-xs text-gray-400 space-y-1">
                <div className="font-medium text-gray-300 mb-1">Przydatne komendy:</div>
                <div>• Uruchom Ollama: <code className="text-blue-400">ollama serve</code></div>
                <div>• Lista modeli: <code className="text-blue-400">ollama list</code></div>
                <div>• Pobierz model: <code className="text-blue-400">ollama pull [nazwa]</code></div>
              </div>
            </div>
          )}

          {settings.aiProvider === 'openai' && (
            <div className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              Używa klucza API skonfigurowanego w Supabase Edge Functions
            </div>
          )}
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div key={message.id}>
            <div
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-lg px-4 py-2 ${
                  message.role === 'user'
                    ? 'bg-[#0e639c] text-white'
                    : 'bg-[#2d2d30] text-gray-200'
                }`}
              >
                <div className="text-sm whitespace-pre-wrap break-words">{message.content}</div>
                <div className="text-xs opacity-60 mt-1">
                  {message.timestamp.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>

            {/* Actions */}
            {message.actions && message.actions.length > 0 && (
              <div className="mt-3 space-y-2">
                {message.actions.map((action: any) => (
                  <div
                    key={action.id}
                    className={`p-3 rounded-lg border ${
                      action.executed 
                        ? 'bg-green-900/20 border-green-700' 
                        : action.rejected
                        ? 'bg-gray-800/50 border-gray-700'
                        : 'bg-blue-900/20 border-blue-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          {action.executed && <span className="text-green-500">✓</span>}
                          {action.rejected && <span className="text-gray-500">⏭️</span>}
                          <span className="font-medium text-sm">{action.title}</span>
                        </div>
                        {action.description && (
                          <p className="text-xs text-gray-400 mt-1">{action.description}</p>
                        )}
                      </div>
                      {!action.executed && !action.rejected && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleExecuteAction(action, index)}
                            className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-xs rounded whitespace-nowrap transition-colors cursor-pointer"
                            title="Wykonaj akcję"
                            disabled={isLoading}
                          >
                            ✓ Wykonaj
                          </button>
                          <button
                            onClick={() => handleRejectAction(action, index)}
                            className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white text-xs rounded whitespace-nowrap transition-colors cursor-pointer"
                            title="Pomiń akcję"
                            disabled={isLoading}
                          >
                            ⏭️ Pomiń
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
        {isGenerating && (
          <div className="flex justify-start">
            <div className="bg-[#2d2d30] rounded-lg px-4 py-2">
              <div className="flex items-center gap-2">
                <i className="ri-loader-4-line animate-spin text-gray-400"></i>
                <span className="text-sm text-gray-400">AI myśli...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="border-t border-gray-700 p-3">
        {/* Model Selector - Only for Ollama */}
        {settings.aiProvider === 'ollama' && (
          <div className="mb-3 flex items-center gap-2">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <i className="ri-cpu-line"></i>
              <span>Model:</span>
            </div>
            <select
              value={settings.selectedModel}
              onChange={(e) => onSettingsChange({ ...settings, selectedModel: e.target.value })}
              disabled={availableModels.length === 0}
              className="flex-1 px-2 py-1.5 bg-[#2d2d30] border border-gray-600 rounded text-xs text-gray-200 focus:outline-none focus:border-blue-500 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {availableModels.length > 0 ? (
                availableModels.map(model => (
                  <option key={model} value={model}>{model}</option>
                ))
              ) : (
                <option value="">Brak modeli - kliknij ⚙️ aby połączyć</option>
              )}
            </select>
            <button
              onClick={loadAvailableModels}
              disabled={isLoadingModels}
              className="px-2 py-1.5 bg-[#2d2d30] hover:bg-[#3e3e42] border border-gray-600 text-gray-300 text-xs rounded whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
              title="Odśwież listę modeli"
            >
              {isLoadingModels ? (
                <i className="ri-loader-4-line animate-spin"></i>
              ) : (
                <i className="ri-refresh-line"></i>
              )}
            </button>
          </div>
        )}

        <div className="flex gap-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Napisz wiadomość... (Enter - wyślij, Shift+Enter - nowa linia)"
            disabled={isGenerating}
            rows={1}
            className="flex-1 px-3 py-2 bg-[#2d2d30] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-[#0e639c] disabled:opacity-50 resize-none overflow-y-auto max-h-32"
            style={{ minHeight: '38px' }}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isGenerating}
            className="px-4 py-2 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isGenerating ? (
              <i className="ri-loader-4-line animate-spin"></i>
            ) : (
              <i className="ri-send-plane-fill"></i>
            )}
          </button>
        </div>
        <div className="mt-2 text-xs text-gray-500 flex items-center gap-2">
          <i className="ri-information-line"></i>
          <span>AI może tworzyć, edytować i usuwać pliki. Zawsze sprawdzaj zmiany przed zatwierdzeniem.</span>
        </div>
      </div>
    </div>
  );
}
