import { useState } from 'react';
import GitHubSettings from './GitHubSettings';
import type { Workspace } from '../../../hooks/useWorkspace';

interface HeaderProps {
  onGithubImport: (url: string) => void;
  onManualSync?: () => void;
  isSyncing?: boolean;
  workspaces: Workspace[];
  currentWorkspace?: Workspace;
  onCreateWorkspace: (name: string, description?: string, githubUrl?: string) => Workspace;
  onSwitchWorkspace: (workspaceId: string) => void;
  onDeleteWorkspace: (workspaceId: string) => void;
  onUpdateWorkspace: (workspaceId: string, updates: Partial<Workspace>) => void;
}

export default function Header({ 
  onGithubImport, 
  onManualSync, 
  isSyncing,
  workspaces,
  currentWorkspace,
  onCreateWorkspace,
  onSwitchWorkspace,
  onDeleteWorkspace,
  onUpdateWorkspace
}: HeaderProps) {
  const [showImportModal, setShowImportModal] = useState(false);
  const [showGitHubSettings, setShowGitHubSettings] = useState(false);
  const [showWorkspaceModal, setShowWorkspaceModal] = useState(false);
  const [showWorkspaceMenu, setShowWorkspaceMenu] = useState(false);
  const [showNewWorkspaceModal, setShowNewWorkspaceModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [workspaceToDelete, setWorkspaceToDelete] = useState<string | null>(null);
  const [githubUrl, setGithubUrl] = useState('');
  const [newWorkspaceName, setNewWorkspaceName] = useState('');
  const [newWorkspaceDescription, setNewWorkspaceDescription] = useState('');

  const handleImport = () => {
    if (githubUrl.trim()) {
      onGithubImport(githubUrl);
      setGithubUrl('');
      setShowImportModal(false);
    }
  };

  const handleGithubImportClick = () => {
    // Pobierz zapisane repo z konfiguracji
    const savedConfig = localStorage.getItem('github-config');
    if (savedConfig) {
      const config = JSON.parse(savedConfig);
      if (config.repoUrl) {
        onGithubImport(config.repoUrl);
        return;
      }
    }
    // Jeśli nie ma zapisanego repo, pokaż modal
    setShowImportModal(true);
  };

  const handleCreateWorkspace = () => {
    if (newWorkspaceName.trim()) {
      onCreateWorkspace(newWorkspaceName, newWorkspaceDescription || undefined);
      setNewWorkspaceName('');
      setNewWorkspaceDescription('');
      setShowWorkspaceModal(false);
    }
  };

  const handleDeleteWorkspace = (workspaceId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Czy na pewno chcesz usunąć ten workspace? Wszystkie dane zostaną utracone.')) {
      onDeleteWorkspace(workspaceId);
    }
  };

  const handleDeleteClick = (workspaceId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setWorkspaceToDelete(workspaceId);
    setShowDeleteConfirm(true);
  };

  const handleConfirmDelete = () => {
    if (workspaceToDelete) {
      onDeleteWorkspace(workspaceToDelete);
      setShowDeleteConfirm(false);
      setWorkspaceToDelete(null);
    }
  };

  const handleCancelDelete = () => {
    setShowDeleteConfirm(false);
    setWorkspaceToDelete(null);
  };

  return (
    <>
      <header className="h-14 bg-[#2d2d30] border-b border-gray-700 flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          <img 
            src="https://public.readdy.ai/ai/img_res/449a2b5f-ca8b-4a46-b021-a74a261ba65c.png" 
            alt="Logo" 
            className="h-8 w-8 object-contain"
          />
          <h1 className="text-lg font-semibold text-gray-100">HTML Editor</h1>
          
          {/* Workspace Selector */}
          <div className="relative">
            <button
              onClick={() => setShowWorkspaceMenu(!showWorkspaceMenu)}
              className="flex items-center gap-2 px-3 py-1.5 bg-[#3e3e42] hover:bg-[#4e4e52] rounded transition-colors"
            >
              <i className="ri-folder-3-line text-blue-400"></i>
              <span className="text-sm">{currentWorkspace?.name || 'Workspace'}</span>
              <i className={`ri-arrow-down-s-line transition-transform ${showWorkspaceMenu ? 'rotate-180' : ''}`}></i>
            </button>

            {showWorkspaceMenu && (
              <div className="absolute top-full left-0 mt-1 w-80 bg-[#2d2d30] border border-gray-700 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
                {/* Workspace List */}
                <div className="py-1">
                  {workspaces.map((workspace) => (
                    <div
                      key={workspace.id}
                      className={`px-3 py-2 hover:bg-[#3e3e42] cursor-pointer flex items-center justify-between group ${
                        workspace.id === currentWorkspace?.id ? 'bg-[#3e3e42]' : ''
                      }`}
                      onClick={() => {
                        onSwitchWorkspace(workspace.id);
                        setShowWorkspaceMenu(false);
                      }}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <i className="ri-folder-3-line text-blue-400 text-sm"></i>
                          <span className="text-sm font-medium truncate">{workspace.name}</span>
                          {workspace.id === currentWorkspace?.id && (
                            <i className="ri-check-line text-green-400 text-sm"></i>
                          )}
                        </div>
                        {workspace.description && (
                          <p className="text-xs text-gray-500 ml-6 truncate">{workspace.description}</p>
                        )}
                        {workspace.githubUrl && (
                          <div className="flex items-center gap-1 ml-6 mt-1">
                            <i className="ri-github-fill text-xs text-gray-500"></i>
                            <span className="text-xs text-gray-500 truncate">{workspace.githubUrl}</span>
                          </div>
                        )}
                      </div>
                      <button
                        onClick={(e) => handleDeleteClick(workspace.id, e)}
                        className="p-1 hover:bg-red-500/20 rounded transition-colors opacity-0 group-hover:opacity-100"
                        title="Usuń workspace"
                      >
                        <i className="ri-delete-bin-line text-red-400"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleGithubImportClick}
            className="px-4 py-1.5 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2"
          >
            <i className="ri-download-cloud-line"></i>
            Pobierz z GitHub
          </button>

          <button
            onClick={() => setShowGitHubSettings(true)}
            className="px-4 py-1.5 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2"
          >
            <i className="ri-git-branch-line"></i>
            Synchronizacja GitHub
          </button>

          {onManualSync && (
            <button
              onClick={onManualSync}
              disabled={isSyncing}
              className="px-4 py-1.5 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className={`ri-refresh-line ${isSyncing ? 'animate-spin' : ''}`}></i>
              {isSyncing ? 'Synchronizacja...' : 'Wypchnij zmiany'}
            </button>
          )}
          
          <button className="px-4 py-1.5 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer flex items-center gap-2">
            <i className="ri-save-line"></i>
            Zapisz
          </button>
        </div>
      </header>

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#2d2d30] border border-gray-700 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4 text-gray-100">Import z GitHub</h2>
            <input
              type="text"
              value={githubUrl}
              onChange={(e) => setGithubUrl(e.target.value)}
              placeholder="https://github.com/username/repo"
              className="w-full px-3 py-2 bg-[#1e1e1e] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-[#0e639c]"
            />
            <div className="flex gap-3 mt-6 justify-end">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-4 py-2 bg-[#3e3e42] hover:bg-[#4e4e52] text-gray-200 text-sm rounded whitespace-nowrap transition-colors cursor-pointer"
              >
                Anuluj
              </button>
              <button
                onClick={handleImport}
                className="px-4 py-2 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer"
              >
                Importuj
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Workspace Modal */}
      {showWorkspaceModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#2d2d30] border border-gray-700 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4 text-gray-100">Nowy Workspace</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Nazwa</label>
                <input
                  type="text"
                  value={newWorkspaceName}
                  onChange={(e) => setNewWorkspaceName(e.target.value)}
                  placeholder="Mój Projekt"
                  className="w-full px-3 py-2 bg-[#1e1e1e] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-[#0e639c]"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Opis (opcjonalnie)</label>
                <textarea
                  value={newWorkspaceDescription}
                  onChange={(e) => setNewWorkspaceDescription(e.target.value)}
                  placeholder="Krótki opis projektu..."
                  rows={3}
                  className="w-full px-3 py-2 bg-[#1e1e1e] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-[#0e639c] resize-none"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6 justify-end">
              <button
                onClick={() => {
                  setShowWorkspaceModal(false);
                  setNewWorkspaceName('');
                  setNewWorkspaceDescription('');
                }}
                className="px-4 py-2 bg-[#3e3e42] hover:bg-[#4e4e52] text-gray-200 text-sm rounded whitespace-nowrap transition-colors cursor-pointer"
              >
                Anuluj
              </button>
              <button
                onClick={handleCreateWorkspace}
                disabled={!newWorkspaceName.trim()}
                className="px-4 py-2 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Utwórz
              </button>
            </div>
          </div>
        </div>
      )}

      {/* GitHub Settings Modal */}
      {showGitHubSettings && (
        <GitHubSettings onClose={() => setShowGitHubSettings(false)} />
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={handleCancelDelete}>
          <div className="bg-[#2d2d30] border border-gray-700 rounded-lg p-6 w-96 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <i className="ri-error-warning-line text-red-400 text-xl"></i>
              </div>
              <h3 className="text-lg font-semibold">Usuń Workspace</h3>
            </div>
            
            <p className="text-gray-400 mb-6">
              Czy na pewno chcesz usunąć workspace <span className="font-semibold text-white">"{workspaces.find(w => w.id === workspaceToDelete)?.name}"</span>?
              <br />
              <span className="text-sm text-red-400 mt-2 block">Ta operacja jest nieodwracalna!</span>
            </p>

            <div className="flex gap-3 justify-end">
              <button
                onClick={handleCancelDelete}
                className="px-4 py-2 bg-[#3e3e42] hover:bg-[#4e4e52] rounded transition-colors text-sm"
              >
                Anuluj
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 rounded transition-colors text-sm font-medium"
              >
                Usuń
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
