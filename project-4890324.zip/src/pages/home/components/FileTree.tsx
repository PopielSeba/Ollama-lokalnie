import { useState, useMemo } from 'react';

interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  content?: string;
  path?: string;
  parentPath?: string | null;
  children?: FileNode[];
  isOpen?: boolean;
}

interface FileTreeProps {
  files: FileNode[];
  activeFile: string;
  onFileSelect: (fileId: string) => void;
  onFilesChange: (files: FileNode[]) => void;
}

export default function FileTree({ files, activeFile, onFileSelect, onFilesChange }: FileTreeProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileName, setNewFileName] = useState('');

  // Buduj hierarchię z płaskiej struktury
  const fileTree = useMemo(() => {
    if (files.length === 0) return [];

    // Jeśli pliki już mają strukturę children, użyj jej
    if (files.some(f => f.children !== undefined)) {
      return files;
    }

    // Buduj hierarchię z path/parentPath
    const rootNodes: FileNode[] = [];
    const nodeMap = new Map<string, FileNode>();

    // Najpierw utwórz wszystkie węzły
    files.forEach(file => {
      const node: FileNode = {
        ...file,
        children: file.type === 'folder' ? [] : undefined
      };
      
      if (file.path) {
        nodeMap.set(file.path, node);
      } else {
        nodeMap.set(file.id, node);
      }
    });

    // Następnie zbuduj hierarchię
    files.forEach(file => {
      const node = nodeMap.get(file.path || file.id);
      if (!node) return;

      if (!file.parentPath) {
        // To jest węzeł główny
        rootNodes.push(node);
      } else {
        // Znajdź rodzica i dodaj jako dziecko
        const parent = nodeMap.get(file.parentPath);
        if (parent && parent.children) {
          parent.children.push(node);
        } else {
          // Jeśli nie znaleziono rodzica, dodaj do głównego poziomu
          rootNodes.push(node);
        }
      }
    });

    // Sortuj: foldery przed plikami
    const sortNodes = (nodes: FileNode[]) => {
      nodes.sort((a, b) => {
        if (a.type === 'folder' && b.type === 'file') return -1;
        if (a.type === 'file' && b.type === 'folder') return 1;
        return a.name.localeCompare(b.name);
      });
      
      nodes.forEach(node => {
        if (node.children) {
          sortNodes(node.children);
        }
      });
    };

    sortNodes(rootNodes);
    return rootNodes;
  }, [files]);

  const toggleFolder = (folderId: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(folderId)) {
      newExpanded.delete(folderId);
    } else {
      newExpanded.add(folderId);
    }
    setExpandedFolders(newExpanded);
  };

  const handleCreateFile = () => {
    if (newFileName.trim()) {
      const newFile: FileNode = {
        id: Date.now().toString(),
        name: newFileName,
        type: 'file',
        content: '',
        isOpen: false
      };
      onFilesChange([...files, newFile]);
      setNewFileName('');
      setShowNewFileModal(false);
    }
  };

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.html')) return 'ri-html5-fill text-orange-500';
    if (fileName.endsWith('.css')) return 'ri-css3-fill text-blue-500';
    if (fileName.endsWith('.js') || fileName.endsWith('.jsx')) return 'ri-javascript-fill text-yellow-500';
    if (fileName.endsWith('.ts') || fileName.endsWith('.tsx')) return 'ri-javascript-fill text-blue-400';
    if (fileName.endsWith('.json')) return 'ri-braces-fill text-green-500';
    if (fileName.endsWith('.md')) return 'ri-markdown-fill text-gray-400';
    if (fileName.endsWith('.png') || fileName.endsWith('.jpg') || fileName.endsWith('.svg')) return 'ri-image-fill text-purple-500';
    return 'ri-file-text-line text-gray-400';
  };

  const renderNode = (node: FileNode, depth: number = 0) => {
    const isExpanded = expandedFolders.has(node.id);
    const isActive = activeFile === node.id;

    return (
      <div key={node.id}>
        <div
          className={`flex items-center gap-2 px-3 py-1.5 cursor-pointer hover:bg-[#2d2d30] ${
            isActive ? 'bg-[#37373d]' : ''
          }`}
          style={{ paddingLeft: `${depth * 16 + 12}px` }}
          onClick={() => {
            if (node.type === 'folder') {
              toggleFolder(node.id);
            } else {
              onFileSelect(node.id);
            }
          }}
        >
          {node.type === 'folder' && (
            <i className={`${isExpanded ? 'ri-arrow-down-s-line' : 'ri-arrow-right-s-line'} text-gray-400 text-sm`}></i>
          )}
          <i className={`${node.type === 'folder' ? 'ri-folder-fill text-yellow-600' : getFileIcon(node.name)} text-sm`}></i>
          <span className="text-sm text-gray-300">{node.name}</span>
        </div>
        {node.type === 'folder' && isExpanded && node.children && node.children.length > 0 && (
          <div>
            {node.children.map(child => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  // Policz pliki i foldery
  const fileCount = files.filter(f => f.type === 'file').length;
  const folderCount = files.filter(f => f.type === 'folder').length;

  return (
    <>
      <div className="h-full flex flex-col bg-[#1e1e1e]">
        <div className="h-10 bg-[#2d2d30] border-b border-gray-700 flex items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <i className="ri-folder-open-line text-gray-400"></i>
            <span className="text-sm text-gray-300">Pliki</span>
          </div>
          <button
            onClick={() => setShowNewFileModal(true)}
            className="text-gray-400 hover:text-gray-200 cursor-pointer"
            title="Nowy plik"
          >
            <i className="ri-add-line text-lg"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {fileTree.length === 0 ? (
            <div className="p-4 text-center text-gray-500 text-sm">
              Brak plików. Kliknij + aby dodać nowy plik lub pobierz projekt z GitHub.
            </div>
          ) : (
            fileTree.map(node => renderNode(node))
          )}
        </div>

        <div className="border-t border-gray-700 p-3">
          <div className="text-xs text-gray-500 space-y-1">
            <div className="flex items-center gap-2">
              <i className="ri-folder-line"></i>
              <span>{folderCount} folderów</span>
            </div>
            <div className="flex items-center gap-2">
              <i className="ri-file-list-line"></i>
              <span>{fileCount} plików</span>
            </div>
            <div className="flex items-center gap-2">
              <i className="ri-database-2-line"></i>
              <span>Projekt lokalny</span>
            </div>
          </div>
        </div>
      </div>

      {/* New File Modal */}
      {showNewFileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-[#2d2d30] border border-gray-700 rounded-lg p-6 w-full max-w-md">
            <h2 className="text-xl font-semibold mb-4 text-gray-100">Nowy plik</h2>
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleCreateFile()}
              placeholder="nazwa-pliku.html"
              className="w-full px-3 py-2 bg-[#1e1e1e] border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:border-[#0e639c]"
              autoFocus
            />
            <div className="flex gap-3 mt-6 justify-end">
              <button
                onClick={() => setShowNewFileModal(false)}
                className="px-4 py-2 bg-[#3e3e42] hover:bg-[#4e4e52] text-gray-200 text-sm rounded whitespace-nowrap transition-colors cursor-pointer"
              >
                Anuluj
              </button>
              <button
                onClick={handleCreateFile}
                className="px-4 py-2 bg-[#0e639c] hover:bg-[#1177bb] text-white text-sm rounded whitespace-nowrap transition-colors cursor-pointer"
              >
                Utwórz
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
