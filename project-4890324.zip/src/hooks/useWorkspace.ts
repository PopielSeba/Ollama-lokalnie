import { useState, useEffect } from 'react';

export interface Workspace {
  id: string;
  name: string;
  description?: string;
  githubUrl?: string;
  createdAt: Date;
  updatedAt: Date;
  lastAccessedAt: Date;
}

export interface WorkspaceFile {
  id: string;
  name: string;
  path: string;
  parentPath: string | null;
  type: 'file' | 'folder';
  content?: string;
  isOpen?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  actions?: any[];
}

export interface WorkspaceSettings {
  aiProvider: 'ollama' | 'openai';
  selectedModel: string;
  ollamaUrl: string;
  activeFileId?: string;
}

const DEFAULT_OLLAMA_URL = 'http://127.0.0.1:11434';
const DEFAULT_MODEL = 'deepseek-coder:6.7b';

// IndexedDB helper functions
const DB_NAME = 'WorkspaceDB';
const DB_VERSION = 3;
const STORES = {
  WORKSPACES: 'workspaces',
  FILES: 'files',
  MESSAGES: 'messages',
  SETTINGS: 'settings',
};

let dbInstance: IDBDatabase | null = null;

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(request.result);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      
      // Usuń stare magazyny jeśli istnieją
      const storeNames = Array.from(db.objectStoreNames);
      storeNames.forEach(name => {
        if (Object.values(STORES).includes(name)) {
          try {
            db.deleteObjectStore(name);
          } catch (e) {
            console.log(`Nie można usunąć ${name}:`, e);
          }
        }
      });

      // Utwórz nowe magazyny
      db.createObjectStore(STORES.WORKSPACES);
      db.createObjectStore(STORES.FILES);
      db.createObjectStore(STORES.MESSAGES);
      db.createObjectStore(STORES.SETTINGS);
    };
  });
};

const saveToIndexedDB = async (storeName: string, key: string, value: any): Promise<void> => {
  try {
    const db = await openDB();
    
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.put(value, key);

        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      } catch (error) {
        console.error(`Błąd podczas zapisu do ${storeName}:`, error);
        reject(error);
      }
    });
  } catch (error) {
    console.error(`Błąd otwierania bazy dla ${storeName}:`, error);
    throw error;
  }
};

const getFromIndexedDB = async (storeName: string, key: string): Promise<any> => {
  try {
    const db = await openDB();
    
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction([storeName], 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.get(key);

        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      } catch (error) {
        console.error(`Błąd podczas odczytu z ${storeName}:`, error);
        reject(error);
      }
    });
  } catch (error) {
    console.error(`Błąd otwierania bazy dla ${storeName}:`, error);
    return null;
  }
};

const deleteFromIndexedDB = async (storeName: string, key: string): Promise<void> => {
  try {
    const db = await openDB();
    
    return new Promise((resolve, reject) => {
      try {
        const transaction = db.transaction([storeName], 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(key);

        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      } catch (error) {
        console.error(`Błąd podczas usuwania z ${storeName}:`, error);
        reject(error);
      }
    });
  } catch (error) {
    console.error(`Błąd otwierania bazy dla ${storeName}:`, error);
  }
};

export function useWorkspace() {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [currentWorkspaceId, setCurrentWorkspaceId] = useState<string | null>(null);
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [settings, setSettings] = useState<WorkspaceSettings>({
    aiProvider: 'ollama',
    selectedModel: DEFAULT_MODEL,
    ollamaUrl: DEFAULT_OLLAMA_URL,
  });
  const [isLoading, setIsLoading] = useState(true);

  // Inicjalizacja - wczytaj workspace'y
  useEffect(() => {
    loadWorkspaces();
  }, []);

  // Wczytaj dane aktualnego workspace
  useEffect(() => {
    if (currentWorkspaceId) {
      loadWorkspaceData(currentWorkspaceId);
    }
  }, [currentWorkspaceId]);

  // Automatyczne zapisywanie plików (z debounce)
  useEffect(() => {
    if (currentWorkspaceId && files.length > 0 && !isLoading) {
      const timer = setTimeout(() => {
        saveWorkspaceFiles(currentWorkspaceId, files);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [files, currentWorkspaceId, isLoading]);

  // Automatyczne zapisywanie wiadomości (z debounce)
  useEffect(() => {
    if (currentWorkspaceId && messages.length > 0 && !isLoading) {
      const timer = setTimeout(() => {
        saveWorkspaceMessages(currentWorkspaceId, messages);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [messages, currentWorkspaceId, isLoading]);

  // Automatyczne zapisywanie ustawień
  useEffect(() => {
    if (currentWorkspaceId && !isLoading) {
      saveWorkspaceSettings(currentWorkspaceId, settings);
    }
  }, [settings, currentWorkspaceId, isLoading]);

  const loadWorkspaces = async () => {
    try {
      // Wczytaj z IndexedDB
      const stored = await getFromIndexedDB(STORES.WORKSPACES, 'all');
      
      if (stored && stored.length > 0) {
        const workspacesWithDates = stored.map((w: any) => ({
          ...w,
          createdAt: new Date(w.createdAt),
          updatedAt: new Date(w.updatedAt),
          lastAccessedAt: new Date(w.lastAccessedAt),
        }));
        setWorkspaces(workspacesWithDates);

        // Ustaw ostatnio używany workspace jako aktywny
        const lastWorkspaceId = localStorage.getItem('last-workspace-id');
        if (lastWorkspaceId && workspacesWithDates.find((w: Workspace) => w.id === lastWorkspaceId)) {
          setCurrentWorkspaceId(lastWorkspaceId);
        } else if (workspacesWithDates.length > 0) {
          setCurrentWorkspaceId(workspacesWithDates[0].id);
        }
      } else {
        // Utwórz domyślny workspace
        await createDefaultWorkspace();
      }
    } catch (error) {
      console.error('Błąd wczytywania workspace:', error);
      await createDefaultWorkspace();
    } finally {
      setIsLoading(false);
    }
  };

  const createDefaultWorkspace = async () => {
    const defaultWorkspace: Workspace = {
      id: `workspace-${Date.now()}`,
      name: 'Mój Projekt',
      description: 'Domyślny workspace',
      createdAt: new Date(),
      updatedAt: new Date(),
      lastAccessedAt: new Date(),
    };

    const defaultFiles: WorkspaceFile[] = [
      {
        id: '1',
        name: 'index.html',
        path: 'index.html',
        parentPath: null,
        type: 'file',
        content: '<h1>Hello World</h1>',
        isOpen: true,
      },
    ];

    const defaultMessages: ChatMessage[] = [
      {
        id: '1',
        role: 'assistant',
        content: 'Cześć! 👋 Jestem Twoim AI asystentem z pełnymi uprawnieniami do edycji projektu.\n\nMogę:\n✅ Tworzyć nowe pliki\n✅ Edytować istniejące pliki\n✅ Usuwać pliki\n✅ Instalować pakiety\n✅ Uruchamiać komendy\n✅ Refaktoryzować kod\n✅ Naprawiać błędy\n\nJak mogę Ci pomóc?',
        timestamp: new Date(),
      },
    ];

    const defaultSettings: WorkspaceSettings = {
      aiProvider: 'ollama',
      selectedModel: DEFAULT_MODEL,
      ollamaUrl: DEFAULT_OLLAMA_URL,
    };

    setWorkspaces([defaultWorkspace]);
    setCurrentWorkspaceId(defaultWorkspace.id);
    setFiles(defaultFiles);
    setMessages(defaultMessages);
    setSettings(defaultSettings);

    // Zapisz do IndexedDB
    await saveToIndexedDB(STORES.WORKSPACES, 'all', [defaultWorkspace]);
    localStorage.setItem('last-workspace-id', defaultWorkspace.id);
    
    await saveWorkspaceFiles(defaultWorkspace.id, defaultFiles);
    await saveWorkspaceMessages(defaultWorkspace.id, defaultMessages);
    await saveWorkspaceSettings(defaultWorkspace.id, defaultSettings);
  };

  const loadWorkspaceData = async (workspaceId: string) => {
    setIsLoading(true);
    
    try {
      // Wczytaj pliki z IndexedDB
      const filesKey = `workspace-${workspaceId}-files`;
      const storedFiles = await getFromIndexedDB(STORES.FILES, filesKey);
      if (storedFiles) {
        console.log('📂 Wczytano pliki:', storedFiles.length);
        setFiles(storedFiles);
      } else {
        console.log('📂 Brak zapisanych plików');
        setFiles([]);
      }

      // Wczytaj wiadomości z IndexedDB
      const messagesKey = `workspace-${workspaceId}-messages`;
      const storedMessages = await getFromIndexedDB(STORES.MESSAGES, messagesKey);
      if (storedMessages) {
        const messagesWithDates = storedMessages.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp),
        }));
        setMessages(messagesWithDates);
      } else {
        // Domyślna wiadomość powitalna
        setMessages([
          {
            id: '1',
            role: 'assistant',
            content: 'Cześć! 👋 Jestem Twoim AI asystentem z pełnymi uprawnieniami do edycji projektu.\n\nMogę:\n✅ Tworzyć nowe pliki\n✅ Edytować istniejące pliki\n✅ Usuwać pliki\n✅ Instalować pakiety\n✅ Uruchamiać komendy\n✅ Refaktoryzować kod\n✅ Naprawiać błędy\n\nJak mogę Ci pomóc?',
            timestamp: new Date(),
          },
        ]);
      }

      // Wczytaj ustawienia z IndexedDB
      const settingsKey = `workspace-${workspaceId}-settings`;
      const storedSettings = await getFromIndexedDB(STORES.SETTINGS, settingsKey);
      if (storedSettings) {
        setSettings(storedSettings);
      } else {
        setSettings({
          aiProvider: 'ollama',
          selectedModel: DEFAULT_MODEL,
          ollamaUrl: DEFAULT_OLLAMA_URL,
        });
      }

      // Zaktualizuj lastAccessedAt
      updateWorkspaceAccess(workspaceId);
      localStorage.setItem('last-workspace-id', workspaceId);
    } catch (error) {
      console.error('Błąd wczytywania danych workspace:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveWorkspaceFiles = async (workspaceId: string, files: WorkspaceFile[]) => {
    try {
      const key = `workspace-${workspaceId}-files`;
      await saveToIndexedDB(STORES.FILES, key, files);
      console.log('💾 Zapisano pliki:', files.length);
      updateWorkspaceTimestamp(workspaceId);
    } catch (error) {
      console.error('Błąd zapisywania plików:', error);
    }
  };

  const saveWorkspaceMessages = async (workspaceId: string, messages: ChatMessage[]) => {
    try {
      const key = `workspace-${workspaceId}-messages`;
      await saveToIndexedDB(STORES.MESSAGES, key, messages);
      updateWorkspaceTimestamp(workspaceId);
    } catch (error) {
      console.error('Błąd zapisywania wiadomości:', error);
    }
  };

  const saveWorkspaceSettings = async (workspaceId: string, settings: WorkspaceSettings) => {
    try {
      const key = `workspace-${workspaceId}-settings`;
      await saveToIndexedDB(STORES.SETTINGS, key, settings);
    } catch (error) {
      console.error('Błąd zapisywania ustawień:', error);
    }
  };

  const updateWorkspaceTimestamp = async (workspaceId: string) => {
    setWorkspaces((prev) => {
      const updated = prev.map((w) =>
        w.id === workspaceId ? { ...w, updatedAt: new Date() } : w
      );
      saveToIndexedDB(STORES.WORKSPACES, 'all', updated);
      return updated;
    });
  };

  const updateWorkspaceAccess = async (workspaceId: string) => {
    setWorkspaces((prev) => {
      const updated = prev.map((w) =>
        w.id === workspaceId ? { ...w, lastAccessedAt: new Date() } : w
      );
      saveToIndexedDB(STORES.WORKSPACES, 'all', updated);
      return updated;
    });
  };

  const createWorkspace = (name: string, description?: string, githubUrl?: string) => {
    const newWorkspace: Workspace = {
      id: `workspace-${Date.now()}`,
      name,
      description,
      githubUrl,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastAccessedAt: new Date(),
    };

    const updatedWorkspaces = [...workspaces, newWorkspace];
    setWorkspaces(updatedWorkspaces);
    saveToIndexedDB(STORES.WORKSPACES, 'all', updatedWorkspaces);

    // Przełącz na nowy workspace
    switchWorkspace(newWorkspace.id);

    return newWorkspace;
  };

  const deleteWorkspace = async (workspaceId: string) => {
    try {
      // Usuń dane workspace z IndexedDB
      await deleteFromIndexedDB(STORES.FILES, `workspace-${workspaceId}-files`);
      await deleteFromIndexedDB(STORES.MESSAGES, `workspace-${workspaceId}-messages`);
      await deleteFromIndexedDB(STORES.SETTINGS, `workspace-${workspaceId}-settings`);

      // Usuń workspace z listy
      const updatedWorkspaces = workspaces.filter((w) => w.id !== workspaceId);
      setWorkspaces(updatedWorkspaces);
      await saveToIndexedDB(STORES.WORKSPACES, 'all', updatedWorkspaces);

      // Jeśli usunięto aktywny workspace, przełącz na inny
      if (currentWorkspaceId === workspaceId) {
        if (updatedWorkspaces.length > 0) {
          switchWorkspace(updatedWorkspaces[0].id);
        } else {
          await createDefaultWorkspace();
        }
      }
    } catch (error) {
      console.error('Błąd usuwania workspace:', error);
    }
  };

  const switchWorkspace = (workspaceId: string) => {
    setCurrentWorkspaceId(workspaceId);
  };

  const updateWorkspace = async (workspaceId: string, updates: Partial<Workspace>) => {
    setWorkspaces((prev) => {
      const updated = prev.map((w) =>
        w.id === workspaceId ? { ...w, ...updates, updatedAt: new Date() } : w
      );
      saveToIndexedDB(STORES.WORKSPACES, 'all', updated);
      return updated;
    });
  };

  const currentWorkspace = workspaces.find((w) => w.id === currentWorkspaceId);

  return {
    workspaces,
    currentWorkspace,
    currentWorkspaceId,
    files,
    messages,
    settings,
    setFiles,
    setMessages,
    setSettings,
    createWorkspace,
    deleteWorkspace,
    switchWorkspace,
    updateWorkspace,
    isLoading,
  };
}
