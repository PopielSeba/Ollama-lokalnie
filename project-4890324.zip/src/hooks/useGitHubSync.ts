import { useEffect, useRef, useState } from 'react';

interface GitHubConfig {
  token: string;
  repoUrl: string;
  branch: string;
  autoSync: boolean;
  syncInterval: number;
}

interface SyncStatus {
  isSyncing: boolean;
  lastSync: Date | null;
  error: string | null;
}

export function useGitHubSync(files: any[]) {
  const [config, setConfig] = useState<GitHubConfig | null>(null);
  const [status, setStatus] = useState<SyncStatus>({
    isSyncing: false,
    lastSync: null,
    error: null,
  });
  const syncIntervalRef = useRef<number | null>(null);
  const pendingChangesRef = useRef<Set<string>>(new Set());
  const fileHashesRef = useRef<Map<string, string>>(new Map()); // Śledzenie hash'y plików

  useEffect(() => {
    // Wczytaj konfigurację
    const loadConfig = () => {
      const saved = localStorage.getItem('github-config');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.token && parsed.repoUrl && parsed.autoSync) {
          setConfig(parsed);
        }
      }
    };

    loadConfig();

    // Nasłuchuj zmian konfiguracji
    const handleSyncEnabled = (e: any) => {
      setConfig(e.detail);
    };

    const handleSyncDisabled = () => {
      setConfig(null);
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
        syncIntervalRef.current = null;
      }
    };

    window.addEventListener('github-sync-enabled', handleSyncEnabled);
    window.addEventListener('github-sync-disabled', handleSyncDisabled);

    return () => {
      window.removeEventListener('github-sync-enabled', handleSyncEnabled);
      window.removeEventListener('github-sync-disabled', handleSyncDisabled);
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
      }
    };
  }, []);

  // Funkcja do obliczania prostego hash'a
  const simpleHash = (str: string): string => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(36);
  };

  const syncToGitHub = async (changedFiles?: string[]) => {
    if (!config || status.isSyncing) return;

    setStatus((prev) => ({ ...prev, isSyncing: true, error: null }));

    try {
      console.log('🚀 Rozpoczynam synchronizację z GitHub...');
      console.log('📋 Konfiguracja:', {
        repoUrl: config.repoUrl,
        branch: config.branch,
        hasToken: !!config.token,
        tokenLength: config.token?.length
      });

      const urlParts = config.repoUrl.replace('https://github.com/', '').split('/');
      const repoOwner = urlParts[0];
      const repoName = urlParts[1]?.replace('.git', '');

      console.log('📦 Repozytorium:', { repoOwner, repoName });

      // Przygotuj pliki do commita
      let filesToCommit = changedFiles
        ? files.filter((f) => changedFiles.includes(f.path))
        : files;

      // Filtruj tylko pliki (nie foldery)
      let validFiles = filesToCommit.filter((f) => f.type === 'file' && f.content && f.path);

      // Sprawdź które pliki się zmieniły (porównaj hash'e)
      const changedValidFiles = validFiles.filter(file => {
        const currentHash = simpleHash(file.content);
        const previousHash = fileHashesRef.current.get(file.path);
        
        if (previousHash === undefined) {
          // Nowy plik
          console.log(`🆕 Nowy plik: ${file.path}`);
          return true;
        }
        
        if (previousHash !== currentHash) {
          // Zmieniony plik
          console.log(`🔄 Zmieniony plik: ${file.path}`);
          return true;
        }
        
        // Plik bez zmian
        return false;
      });

      console.log('📁 Wszystkich plików:', validFiles.length);
      console.log('📝 Plików do wysłania (zmienione/nowe):', changedValidFiles.length);
      console.log('📄 Lista plików do wysłania:', changedValidFiles.map(f => f.path));

      if (changedValidFiles.length === 0) {
        console.log('✅ Wszystkie pliki są już zsynchronizowane - brak zmian');
        setStatus((prev) => ({ ...prev, isSyncing: false, lastSync: new Date() }));
        return;
      }

      // Podziel pliki na partie po 50 (dla bezpieczeństwa API)
      const batchSize = 50;
      const batches = [];
      for (let i = 0; i < changedValidFiles.length; i += batchSize) {
        batches.push(changedValidFiles.slice(i, i + batchSize));
      }

      console.log(`📦 Podzielono na ${batches.length} partii po max ${batchSize} plików`);

      // Wyślij każdą partię
      for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];
        console.log(`📤 Wysyłam partię ${i + 1}/${batches.length} (${batch.length} plików)...`);

        const fileContents = batch.map((file) => ({
          path: file.path,
          content: file.content || '',
        }));

        const dataSize = JSON.stringify(fileContents).length;
        console.log(`📊 Rozmiar danych partii ${i + 1}:`, (dataSize / 1024).toFixed(2), 'KB');

        const requestBody = {
          action: 'commit-push',
          repoOwner,
          repoName,
          branch: config.branch,
          files: fileContents,
          commitMessage: `Auto-sync (${i + 1}/${batches.length}): ${new Date().toLocaleString('pl-PL')}`,
          githubToken: config.token,
        };

        const response = await fetch(
          `${import.meta.env.VITE_PUBLIC_SUPABASE_URL}/functions/v1/github-sync`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody),
          }
        );

        console.log(`📥 Odpowiedź HTTP partii ${i + 1}:`, response.status, response.statusText);

        const data = await response.json();
        console.log(`📊 Dane odpowiedzi partii ${i + 1}:`, data);

        if (!data.success) {
          throw new Error(data.error || `Błąd synchronizacji partii ${i + 1}`);
        }

        // Zaktualizuj hash'e zsynchronizowanych plików
        batch.forEach(file => {
          const hash = simpleHash(file.content);
          fileHashesRef.current.set(file.path, hash);
        });
        
        console.log(`✅ Partia ${i + 1}/${batches.length} zsynchronizowana!`);

        // Krótka przerwa między partiami (aby nie przeciążyć API)
        if (i < batches.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      console.log('✅ Wszystkie partie zsynchronizowane pomyślnie!');
      console.log(`📊 Zsynchronizowano ${changedValidFiles.length} z ${validFiles.length} plików`);

      setStatus({
        isSyncing: false,
        lastSync: new Date(),
        error: null,
      });

      // Wyczyść oczekujące zmiany
      pendingChangesRef.current.clear();

      // Pokaż powiadomienie
      window.dispatchEvent(
        new CustomEvent('github-sync-success', {
          detail: { filesCount: changedValidFiles.length },
        })
      );
    } catch (error: any) {
      console.error('❌ Błąd synchronizacji:', error);
      console.error('📋 Szczegóły błędu:', {
        message: error.message,
        stack: error.stack,
        name: error.name
      });

      setStatus({
        isSyncing: false,
        lastSync: null,
        error: error.message,
      });

      window.dispatchEvent(
        new CustomEvent('github-sync-error', {
          detail: { error: error.message },
        })
      );
    }
  };

  // Automatyczna synchronizacja
  useEffect(() => {
    if (!config || !config.autoSync) {
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
        syncIntervalRef.current = null;
      }
      return;
    }

    // Uruchom synchronizację co X minut
    syncIntervalRef.current = window.setInterval(
      () => {
        if (pendingChangesRef.current.size > 0) {
          syncToGitHub(Array.from(pendingChangesRef.current));
        }
      },
      config.syncInterval * 60 * 1000
    );

    return () => {
      if (syncIntervalRef.current) {
        clearInterval(syncIntervalRef.current);
      }
    };
  }, [config, files]);

  // Śledź zmiany w plikach
  const markFileChanged = (filePath: string) => {
    pendingChangesRef.current.add(filePath);
  };

  return {
    isEnabled: !!config,
    status,
    syncToGitHub,
    markFileChanged,
  };
}
