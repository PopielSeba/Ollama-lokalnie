import { useState, useCallback, useEffect } from 'react';

// Typy
export interface AIAgent {
  id: string;
  name: string;
  role: 'router' | 'planner' | 'coder';
  model: string;
  status: 'idle' | 'active' | 'loading' | 'error';
  vram: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: 'router' | 'planner' | 'coder';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  priority: 'low' | 'medium' | 'high';
  createdAt: Date;
  completedAt?: Date;
}

export interface AgentMessage {
  id: string;
  agent: 'system' | 'router' | 'planner' | 'coder';
  content: string;
  type: 'info' | 'success' | 'error' | 'warning';
  timestamp: Date;
}

export interface MultiAgentSettings {
  ollamaUrl: string;
  routerModel: string;
  plannerModel: string;
  coderModel: string;
}

const DEFAULT_SETTINGS: MultiAgentSettings = {
  ollamaUrl: 'http://localhost:11434',
  routerModel: 'llama3.1:8b',
  plannerModel: 'qwen2.5:14b',
  coderModel: 'deepseek-coder:33b',
};

export function useMultiAgentAI(onTerminalOutput?: (message: string) => void) {
  // Wczytaj ustawienia z localStorage
  const loadSettings = (): MultiAgentSettings => {
    try {
      const stored = localStorage.getItem('multi-agent-settings');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (error) {
      console.error('Błąd wczytywania ustawień:', error);
    }
    return DEFAULT_SETTINGS;
  };

  const [settings, setSettingsState] = useState<MultiAgentSettings>(loadSettings);
  const [agents, setAgents] = useState<AIAgent[]>([
    { id: '1', name: 'Router', role: 'router', model: settings.routerModel, status: 'idle', vram: '~2GB' },
    { id: '2', name: 'Planner', role: 'planner', model: settings.plannerModel, status: 'idle', vram: '~8GB' },
    { id: '3', name: 'Coder', role: 'coder', model: settings.coderModel, status: 'idle', vram: '~4GB' },
  ]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [ollamaConnected, setOllamaConnected] = useState(false);
  const [isTestingConnection, setIsTestingConnection] = useState(false);

  // Synchronizuj agentów z ustawieniami
  useEffect(() => {
    setAgents(prev => prev.map(agent => {
      if (agent.role === 'router') {
        return { ...agent, model: settings.routerModel };
      } else if (agent.role === 'planner') {
        return { ...agent, model: settings.plannerModel };
      } else if (agent.role === 'coder') {
        return { ...agent, model: settings.coderModel };
      }
      return agent;
    }));
  }, [settings.routerModel, settings.plannerModel, settings.coderModel]);

  // Zapisz ustawienia do localStorage
  const updateSettings = useCallback((newSettings: MultiAgentSettings) => {
    setSettingsState(newSettings);
    localStorage.setItem('multi-agent-settings', JSON.stringify(newSettings));
  }, []);

  // Test połączenia z Ollama
  const testOllamaConnection = useCallback(async () => {
    setIsTestingConnection(true);
    try {
      const response = await fetch(`${settings.ollamaUrl}/api/tags`);
      if (response.ok) {
        const data = await response.json();
        setOllamaConnected(true);
        setAvailableModels(data.models?.map((m: any) => m.name) || []);
        if (onTerminalOutput) {
          onTerminalOutput(`✅ Połączono z Ollama (${settings.ollamaUrl}) - znaleziono ${data.models?.length || 0} modeli`);
        }
        return true;
      } else {
        setOllamaConnected(false);
        if (onTerminalOutput) {
          onTerminalOutput(`❌ Nie można połączyć z Ollama (${settings.ollamaUrl})`);
        }
        return false;
      }
    } catch (error) {
      setOllamaConnected(false);
      if (onTerminalOutput) {
        onTerminalOutput(`❌ Błąd połączenia z Ollama: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      }
      return false;
    } finally {
      setIsTestingConnection(false);
    }
  }, [settings.ollamaUrl, onTerminalOutput]);

  // Wczytaj dostępne modele
  const loadAvailableModels = useCallback(async () => {
    try {
      const response = await fetch(`${settings.ollamaUrl}/api/tags`);
      if (response.ok) {
        const data = await response.json();
        setAvailableModels(data.models?.map((m: any) => m.name) || []);
        setOllamaConnected(true);
      }
    } catch (error) {
      console.error('Błąd wczytywania modeli:', error);
      setOllamaConnected(false);
    }
  }, [settings.ollamaUrl]);

  // Dodaj wiadomość
  const addMessage = useCallback((agent: AgentMessage['agent'], content: string, type: AgentMessage['type'] = 'info') => {
    const message: AgentMessage = {
      id: `msg-${Date.now()}-${Math.random()}`,
      agent,
      content,
      type,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, message]);
  }, []);

  // Dodaj zadanie
  const addTask = useCallback((title: string, description: string, assignedTo: Task['assignedTo'], priority: Task['priority'] = 'medium') => {
    const task: Task = {
      id: `task-${Date.now()}-${Math.random()}`,
      title,
      description,
      assignedTo,
      status: 'pending',
      priority,
      createdAt: new Date(),
    };
    setTasks(prev => [...prev, task]);
    return task;
  }, []);

  // Aktualizuj status agenta
  const updateAgentStatus = useCallback((role: AIAgent['role'], status: AIAgent['status']) => {
    setAgents(prev => prev.map(agent => 
      agent.role === role ? { ...agent, status } : agent
    ));
  }, []);

  // Aktualizuj status zadania
  const updateTaskStatus = useCallback((taskId: string, status: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId 
        ? { ...task, status, completedAt: status === 'completed' ? new Date() : task.completedAt }
        : task
    ));
  }, []);

  // 🎯 RAG: Semantic search - find relevant files
  const findRelevantFiles = (query: string, projectContext: any, maxFiles: number = 10): any[] => {
    if (!projectContext.files || projectContext.files.length === 0) {
      return [];
    }

    const queryLower = query.toLowerCase();
    const keywords = queryLower.split(/\s+/).filter(k => k.length > 2);
    
    const scoredFiles = projectContext.files
      .filter((f: any) => f.type === 'file' && f.content)
      .map((file: any) => {
        let score = 0;
        const content = file.content?.toLowerCase() || '';
        const path = file.path.toLowerCase();
        const name = file.name.toLowerCase();
        
        if (content.includes(queryLower)) score += 100;
        
        keywords.forEach(keyword => {
          if (name.includes(keyword)) score += 50;
          if (path.includes(keyword)) score += 30;
        });
        
        keywords.forEach(keyword => {
          const matches = (content.match(new RegExp(keyword, 'g')) || []).length;
          score += matches * 10;
        });
        
        if (name.includes('config') || name.includes('price') || name.includes('plan')) score += 20;
        if (name.includes('landing') || name.includes('home') || name.includes('index')) score += 15;
        
        return { file, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, maxFiles);
    
    return scoredFiles.map(item => item.file);
  };

  // 🎯 RAG: Build context from relevant files
  const buildProjectContext = (query: string, projectContext: any): string => {
    const relevantFiles = findRelevantFiles(query, projectContext, 10);
    
    if (relevantFiles.length === 0) {
      return `📂 KONTEKST PROJEKTU: Brak plików w workspace.`;
    }
    
    const contextParts = relevantFiles.map((file: any) => {
      return `📄 ${file.path}:\n\`\`\`\n${file.content}\n\`\`\``;
    });
    
    return `📂 KONTEKST PROJEKTU (${relevantFiles.length} relewantnych plików):\n\n${contextParts.join('\n\n---\n\n')}`;
  };

  // 🎯 ROUTER AGENT - System Prompt
  const getRouterSystemPrompt = (): string => {
    return `Jesteś ROUTER AGENT - klasyfikujesz zapytania użytkownika.

🎯 TWOJA ROLA:
Analizujesz pytanie użytkownika i decydujesz:
- SIMPLE: Proste pytanie o projekt (odpowiadasz SAM na podstawie kontekstu)
- TASK: Zadanie do wykonania (→ CODER)
- COMPLEX: Złożone zadanie (→ PLANNER)

⚠️ KRYTYCZNE ZASADY:
1. Masz dostęp do plików projektu w kontekście
2. Dla SIMPLE - odpowiadasz cytując konkretne pliki
3. Zwracaj TYLKO czysty JSON w formacie poniżej
4. NIE UŻYWAJ fraz: "nie mam dostępu", "jako model"

📋 FORMAT ODPOWIEDZI (ZAWSZE ten sam!):

Dla SIMPLE (odpowiadasz sam):
{
  "decision": "SIMPLE",
  "confidence": "high",
  "message": "Znalazłem [info] w pliku [ścieżka]:\\n\\n\`\`\`[kod]\`\`\`\\n\\n(linia [nr])",
  "next_agent": null
}

Gdy brak danych:
{
  "decision": "SIMPLE",
  "confidence": "low",
  "message": "Nie znalazłem [czego] w projekcie. Przeszukałem: [lista plików]",
  "next_agent": null
}

Dla TASK:
{
  "decision": "TASK",
  "confidence": "high",
  "message": "Przekazuję do CODER: [opis]",
  "next_agent": "coder"
}

Dla COMPLEX:
{
  "decision": "COMPLEX",
  "confidence": "medium",
  "message": "Przekazuję do PLANNER: [opis]",
  "next_agent": "planner"
}

⚠️ PAMIĘTAJ: Zwróć TYLKO JSON bez markdown!`;
  };

  // 🎯 CODER AGENT - System Prompt
  const getCoderSystemPrompt = (): string => {
    return `Jesteś CODER AGENT - wykonujesz zadania programistyczne.

🎯 TWOJA ROLA:
- Wykonujesz konkretne zadania edycji kodu
- Masz pełny dostęp do plików projektu poprzez kontekst RAG
- Generujesz akcje: create_file, edit_file, delete_file, install_package

⚠️ KRYTYCZNE ZASADY:
1. ZAWSZE sprawdzaj kontekst - czy plik istnieje
2. Dla edit_file - cytuj fragment który zmieniasz
3. Dla create_file - sprawdź czy ścieżka jest poprawna
4. Generuj TYLKO akcje które są możliwe do wykonania
5. Zwracaj TYLKO czysty JSON

📋 FORMAT ODPOWIEDZI:

{
  "message": "Wykonuję [opis]...",
  "actions": [
    {
      "type": "edit_file",
      "path": "src/config/pricing.ts",
      "content": "[pełna nowa zawartość pliku]",
      "description": "Zmiana ceny Basic z 29 na 39 zł"
    }
  ]
}`;
  };

  // 🎯 PLANNER AGENT - System Prompt
  const getPlannerSystemPrompt = (): string => {
    return `Jesteś PLANNER AGENT - planujesz złożone zadania.

🎯 TWOJA ROLA:
- Rozbijasz złożone zadania na kroki
- Masz pełny dostęp do plików projektu poprzez kontekst RAG
- Tworzysz plan działania dla CODER

⚠️ KRYTYCZNE ZASADY:
1. Analizuj kontekst projektu przed planowaniem
2. Sprawdź co już istnieje, czego brakuje
3. Rozbij zadanie na logiczne kroki
4. Każdy krok = konkretna akcja dla CODER
5. Zwracaj TYLKO czysty JSON

📋 FORMAT ODPOWIEDZI:

{
  "message": "Plan wykonania: [opis]",
  "plan": [
    {
      "step": 1,
      "description": "Utworzenie struktury folderów",
      "actions": [...]
    }
  ],
  "actions": [...]
}`;
  };

  const processQuery = async (query: string, projectContext: any): Promise<any> => {
    if (!ollamaConnected) {
      throw new Error('Ollama nie jest połączona. Kliknij "Test połączenia" w ustawieniach.');
    }

    setIsProcessing(true);

    try {
      // 🎯 RAG: Build context from relevant files
      const projectContextText = buildProjectContext(query, projectContext);
      const relevantFilesCount = findRelevantFiles(query, projectContext).length;
      
      if (onTerminalOutput) {
        onTerminalOutput(`\n🚀 Rozpoczynam przetwarzanie zapytania: "${query}"\n`);
        onTerminalOutput(`🔍 Znaleziono ${relevantFilesCount} relewantnych plików...`);
      }

      // 🎯 STEP 1: ROUTER - Classify query
      if (onTerminalOutput) {
        onTerminalOutput('🎯 Router analizuje pytanie...');
        onTerminalOutput(`⚙️ Wysyłam zapytanie do modelu ${settings.routerModel}...`);
      }
      
      updateAgentStatus('router', 'active');

      const routerPrompt = `${getRouterSystemPrompt()}

${projectContextText}

---

👤 ZAPYTANIE UŻYTKOWNIKA:
${query}

---

⚠️ Zwróć TYLKO czysty JSON (bez \`\`\`json)!`;

      const routerResponse = await fetch(`${settings.ollamaUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: settings.routerModel,
          prompt: routerPrompt,
          stream: false,
          format: 'json',
          options: { 
            temperature: 0.1,  // ← OBNIŻAM z 0.3 do 0.1 (bardziej deterministyczne)
            num_predict: 1000  // ← DODAJĘ limit tokenów
          }
        }),
      });

      if (!routerResponse.ok) {
        throw new Error(`Router error: ${routerResponse.status}`);
      }

      const routerData = await routerResponse.json();
      let routerResult;
      
      try {
        let cleanResponse = routerData.response.trim();
        
        // Usuń markdown code blocks
        if (cleanResponse.startsWith('```json')) {
          cleanResponse = cleanResponse.replace(/```json\n?/g, '').replace(/```\n?$/g, '');
        } else if (cleanResponse.startsWith('```')) {
          cleanResponse = cleanResponse.replace(/```\n?/g, '');
        }
        
        cleanResponse = cleanResponse.trim();
        
        // Parsuj JSON
        routerResult = JSON.parse(cleanResponse);
        
        // ⚠️ WALIDACJA: Sprawdź czy decision istnieje
        if (!routerResult.decision) {
          if (onTerminalOutput) {
            onTerminalOutput(`⚠️ Router zwrócił nieprawidłowy JSON (brak 'decision')`);
            onTerminalOutput(`📄 Surowa odpowiedź: ${cleanResponse.substring(0, 200)}...`);
          }
          
          // 🔧 FALLBACK: Spróbuj zinterpretować odpowiedź
          // Jeśli model zwrócił dane zamiast decyzji, traktuj jako SIMPLE
          routerResult = {
            decision: 'SIMPLE',
            confidence: 'low',
            message: `Router zwrócił nieprawidłowy format odpowiedzi.\n\nOtrzymane dane:\n${cleanResponse}\n\n⚠️ Sprawdź czy model ${settings.routerModel} jest odpowiedni do tego zadania.\n💡 Zalecane modele: llama3.1:8b, qwen2.5:7b, mistral:7b`,
            next_agent: null
          };
        }
        
        // Loguj do terminala
        if (onTerminalOutput) {
          onTerminalOutput(`📊 Router decision: ${routerResult.decision} (confidence: ${routerResult.confidence})`);
        }
        
      } catch (e) {
        if (onTerminalOutput) {
          onTerminalOutput(`❌ Błąd parsowania JSON od Routera`);
          onTerminalOutput(`📄 Surowa odpowiedź: ${routerData.response.substring(0, 300)}...`);
        }
        
        // Fallback: Zwróć surową odpowiedź jako SIMPLE
        routerResult = {
          decision: 'SIMPLE',
          confidence: 'low',
          message: `Nie mogłem sparsować odpowiedzi od Routera.\n\nSurowa odpowiedź:\n${routerData.response}\n\n⚠️ Model ${settings.routerModel} może nie być odpowiedni do tego zadania.`,
          next_agent: null
        };
      }

      updateAgentStatus('router', 'idle');
      
      if (onTerminalOutput) {
        onTerminalOutput(`✅ Router zakończył analizę (pewność: ${routerResult.confidence})`);
      }

      // 🎯 STEP 2: Handle based on decision
      if (routerResult.decision === 'SIMPLE') {
        // Router answered directly - WYŚWIETL ODPOWIEDŹ W CZACIE!
        if (onTerminalOutput) {
          onTerminalOutput('📝 To proste pytanie - Router odpowiedział\n');
        }
        
        addMessage('router', routerResult.message, 'success');
        
        setIsProcessing(false);
        return [{
          message: routerResult.message,
          actions: [],
          confidence: routerResult.confidence,
          agent: 'router'
        }];
      }

      if (routerResult.decision === 'TASK') {
        // Send to CODER
        if (onTerminalOutput) {
          onTerminalOutput('💻 Coder rozpoczyna wykonywanie...');
          onTerminalOutput(`⚙️ Wysyłam zapytanie do modelu ${settings.coderModel}...`);
        }
        
        updateAgentStatus('coder', 'active');
        
        const coderPrompt = `${getCoderSystemPrompt()}

${projectContextText}

---

👤 ZADANIE:
${query}

📋 ANALIZA ROUTERA:
${routerResult.message}

---

⚠️ Zwróć TYLKO czysty JSON z akcjami!`;

        const coderResponse = await fetch(`${settings.ollamaUrl}/api/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: settings.coderModel,
            prompt: coderPrompt,
            stream: false,
            format: 'json',
            options: { temperature: 0.5 }
          }),
        });

        if (!coderResponse.ok) {
          throw new Error(`Coder error: ${coderResponse.status}`);
        }

        const coderData = await coderResponse.json();
        let coderResult;
        
        try {
          let cleanResponse = coderData.response.trim();
          if (cleanResponse.startsWith('```json')) {
            cleanResponse = cleanResponse.replace(/```json\n?/g, '').replace(/```\n?$/g, '');
          } else if (cleanResponse.startsWith('```')) {
            cleanResponse = cleanResponse.replace(/```\n?/g, '');
          }
          coderResult = JSON.parse(cleanResponse);
        } catch (e) {
          throw new Error('Coder zwrócił nieprawidłowy JSON');
        }

        updateAgentStatus('coder', 'idle');
        
        if (onTerminalOutput) {
          onTerminalOutput(`✅ Coder wygenerował ${coderResult.actions?.length || 0} akcji\n`);
        }

        addMessage('coder', coderResult.message, 'success');

        setIsProcessing(false);
        return [{
          message: coderResult.message,
          actions: coderResult.actions || [],
          confidence: routerResult.confidence,
          agent: 'coder'
        }];
      }

      if (routerResult.decision === 'COMPLEX') {
        // Send to PLANNER
        if (onTerminalOutput) {
          onTerminalOutput('📋 Planner tworzy plan działania...');
          onTerminalOutput(`⚙️ Wysyłam zapytanie do modelu ${settings.plannerModel}...`);
        }
        
        updateAgentStatus('planner', 'active');
        
        const plannerPrompt = `${getPlannerSystemPrompt()}

${projectContextText}

---

👤 ZŁOŻONE ZADANIE:
${query}

📋 ANALIZA ROUTERA:
${routerResult.message}

---

⚠️ Zwróć TYLKO czysty JSON z planem i akcjami!`;

        const plannerResponse = await fetch(`${settings.ollamaUrl}/api/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: settings.plannerModel,
            prompt: plannerPrompt,
            stream: false,
            format: 'json',
            options: { temperature: 0.5 }
          }),
        });

        if (!plannerResponse.ok) {
          throw new Error(`Planner error: ${plannerResponse.status}`);
        }

        const plannerData = await plannerResponse.json();
        let plannerResult;
        
        try {
          let cleanResponse = plannerData.response.trim();
          if (cleanResponse.startsWith('```json')) {
            cleanResponse = cleanResponse.replace(/```json\n?/g, '').replace(/```\n?$/g, '');
          } else if (cleanResponse.startsWith('```')) {
            cleanResponse = cleanResponse.replace(/```\n?/g, '');
          }
          plannerResult = JSON.parse(cleanResponse);
        } catch (e) {
          throw new Error('Planner zwrócił nieprawidłowy JSON');
        }

        updateAgentStatus('planner', 'idle');
        
        if (onTerminalOutput) {
          onTerminalOutput(`✅ Planner utworzył plan z ${plannerResult.plan?.length || 0} krokami\n`);
        }

        addMessage('planner', plannerResult.message, 'success');

        setIsProcessing(false);
        return [{
          message: plannerResult.message,
          actions: plannerResult.actions || [],
          confidence: routerResult.confidence,
          agent: 'planner',
          plan: plannerResult.plan
        }];
      }

      throw new Error(`Router zwrócił nieznany typ decyzji: ${routerResult.decision}`);

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Nieznany błąd';
      addMessage('system', `❌ Błąd przetwarzania: ${errorMsg}`, 'error');
      
      if (onTerminalOutput) {
        onTerminalOutput(`❌ Błąd przetwarzania: ${errorMsg}\n`);
      }
      
      setIsProcessing(false);
      throw error;
    }
  };

  // Wyczyść wiadomości
  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  // Wyczyść zadania
  const clearTasks = useCallback(() => {
    setTasks([]);
  }, []);

  // Zatrzymaj przetwarzanie
  const stopProcessing = useCallback(() => {
    setIsProcessing(false);
    agents.forEach(agent => {
      if (agent.status === 'active' || agent.status === 'loading') {
        updateAgentStatus(agent.role, 'idle');
      }
    });
    if (onTerminalOutput) {
      onTerminalOutput('⏸️ Przetwarzanie zatrzymane przez użytkownika\n');
    }
  }, [agents, onTerminalOutput, updateAgentStatus]);

  return {
    agents,
    tasks,
    messages,
    isProcessing,
    settings,
    availableModels,
    ollamaConnected,
    isTestingConnection,
    processQuery,
    clearMessages,
    clearTasks,
    stopProcessing,
    testOllamaConnection,
    loadAvailableModels,
    updateSettings,
  };
}
