import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { action, repoOwner, repoName, branch, files, commitMessage, githubToken } = await req.json()

    if (!githubToken) {
      throw new Error('GitHub token is required')
    }

    const headers = {
      'Authorization': `Bearer ${githubToken}`,
      'Accept': 'application/vnd.github.v3+json',
      'Content-Type': 'application/json',
    }

    // Get repository info
    if (action === 'get-repo-info') {
      const repoResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}`,
        { headers }
      )

      if (!repoResponse.ok) {
        const error = await repoResponse.json()
        throw new Error(error.message || 'Failed to fetch repository info')
      }

      const repoData = await repoResponse.json()
      return new Response(
        JSON.stringify({ 
          success: true, 
          data: {
            name: repoData.name,
            fullName: repoData.full_name,
            defaultBranch: repoData.default_branch,
            private: repoData.private,
            description: repoData.description,
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get repository tree
    if (action === 'get-tree') {
      const treeResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/trees/${branch}?recursive=1`,
        { headers }
      )

      if (!treeResponse.ok) {
        throw new Error('Failed to fetch repository tree')
      }

      const treeData = await treeResponse.json()
      return new Response(
        JSON.stringify({ success: true, data: treeData }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get file content
    if (action === 'get-file') {
      const { path } = await req.json()
      const fileResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/contents/${path}?ref=${branch}`,
        { headers }
      )

      if (!fileResponse.ok) {
        throw new Error('Failed to fetch file content')
      }

      const fileData = await fileResponse.json()
      return new Response(
        JSON.stringify({ success: true, data: fileData }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Commit and push changes
    if (action === 'commit-push') {
      console.log('🚀 Rozpoczynam commit-push...')
      console.log('📦 Liczba plików:', files?.length || 0)
      
      // Walidacja danych wejściowych
      if (!files || !Array.isArray(files) || files.length === 0) {
        throw new Error('Brak plików do wysłania')
      }

      // Walidacja rozmiaru plików
      const maxFileSize = 1024 * 1024 // 1MB
      for (const file of files) {
        if (!file.path || !file.content) {
          throw new Error(`Nieprawidłowy plik: brak path lub content`)
        }
        const fileSize = new Blob([file.content]).size
        if (fileSize > maxFileSize) {
          throw new Error(`Plik ${file.path} jest zbyt duży (${(fileSize / 1024).toFixed(0)}KB). Max 1MB.`)
        }
      }

      console.log('✅ Walidacja plików zakończona')

      // Get the latest commit SHA
      console.log('📡 Pobieram referencję branch...')
      const refResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/refs/heads/${branch}`,
        { headers }
      )

      if (!refResponse.ok) {
        const errorText = await refResponse.text()
        console.error('❌ Błąd pobierania referencji:', errorText)
        throw new Error(`Failed to get branch reference: ${refResponse.status}`)
      }

      const refData = await refResponse.json()
      const latestCommitSha = refData.object.sha
      console.log('✅ Commit SHA:', latestCommitSha)

      // Get the base tree
      console.log('📡 Pobieram commit...')
      const commitResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/commits/${latestCommitSha}`,
        { headers }
      )

      if (!commitResponse.ok) {
        const errorText = await commitResponse.text()
        console.error('❌ Błąd pobierania commit:', errorText)
        throw new Error(`Failed to get commit: ${commitResponse.status}`)
      }

      const commitData = await commitResponse.json()
      const baseTreeSha = commitData.tree.sha
      console.log('✅ Base tree SHA:', baseTreeSha)

      // Pobierz aktualne drzewo aby sprawdzić istniejące foldery
      console.log('📡 Pobieram aktualne drzewo...')
      const currentTreeResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/trees/${baseTreeSha}?recursive=1`,
        { headers }
      )

      let existingPaths = new Set<string>()
      if (currentTreeResponse.ok) {
        const currentTreeData = await currentTreeResponse.json()
        existingPaths = new Set(currentTreeData.tree.map((item: any) => item.path))
        console.log('✅ Znaleziono istniejących ścieżek:', existingPaths.size)
      }

      // Zbierz wszystkie unikalne foldery z plików
      const folders = new Set<string>()
      for (const file of files) {
        const pathParts = file.path.split('/')
        // Dodaj wszystkie foldery w ścieżce (oprócz nazwy pliku)
        for (let i = 1; i < pathParts.length; i++) {
          const folderPath = pathParts.slice(0, i).join('/')
          if (folderPath && !existingPaths.has(folderPath)) {
            folders.add(folderPath)
          }
        }
      }

      console.log('📁 Nowych folderów do utworzenia:', folders.size)
      if (folders.size > 0) {
        console.log('📋 Lista folderów:', Array.from(folders))
      }

      // Create blobs for each file
      console.log('📤 Tworzę blobs...')
      const treeItems = []
      let blobCount = 0
      
      // Najpierw dodaj foldery (jako tree)
      for (const folderPath of folders) {
        treeItems.push({
          path: folderPath,
          mode: '040000', // Tryb dla folderów
          type: 'tree',
          sha: null // GitHub automatycznie utworzy folder
        })
      }

      // Potem dodaj pliki z prawidłowym kodowaniem UTF-8
      for (const file of files) {
        try {
          // 🔧 NAPRAWIONE: Prawidłowe kodowanie UTF-8 -> base64 dla polskich znaków
          const encoder = new TextEncoder()
          const utf8Bytes = encoder.encode(file.content)
          
          // Konwersja Uint8Array do base64
          let binary = ''
          const len = utf8Bytes.byteLength
          for (let i = 0; i < len; i++) {
            binary += String.fromCharCode(utf8Bytes[i])
          }
          const base64Content = btoa(binary)
          
          const blobResponse = await fetch(
            `https://api.github.com/repos/${repoOwner}/${repoName}/git/blobs`,
            {
              method: 'POST',
              headers,
              body: JSON.stringify({
                content: base64Content,
                encoding: 'base64'
              })
            }
          )

          if (!blobResponse.ok) {
            const errorText = await blobResponse.text()
            console.error(`❌ Błąd tworzenia blob dla ${file.path}:`, errorText)
            throw new Error(`Failed to create blob for ${file.path}: ${blobResponse.status}`)
          }

          const blobData = await blobResponse.json()
          treeItems.push({
            path: file.path,
            mode: '100644',
            type: 'blob',
            sha: blobData.sha
          })
          
          blobCount++
          if (blobCount % 10 === 0) {
            console.log(`⏳ Utworzono ${blobCount}/${files.length} blobs...`)
          }
        } catch (error) {
          console.error(`❌ Błąd dla pliku ${file.path}:`, error)
          throw error
        }
      }

      console.log(`✅ Utworzono ${blobCount} blobs i ${folders.size} folderów`)

      // Create new tree
      console.log('🌳 Tworzę nowe drzewo...')
      const treeResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/trees`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            base_tree: baseTreeSha,
            tree: treeItems
          })
        }
      )

      if (!treeResponse.ok) {
        const errorText = await treeResponse.text()
        console.error('❌ Błąd tworzenia drzewa:', errorText)
        throw new Error(`Failed to create tree: ${treeResponse.status}`)
      }

      const treeData = await treeResponse.json()
      console.log('✅ Tree SHA:', treeData.sha)

      // Create new commit
      console.log('💾 Tworzę commit...')
      const newCommitResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/commits`,
        {
          method: 'POST',
          headers,
          body: JSON.stringify({
            message: commitMessage || 'Update from HTML Editor',
            tree: treeData.sha,
            parents: [latestCommitSha]
          })
        }
      )

      if (!newCommitResponse.ok) {
        const errorText = await newCommitResponse.text()
        console.error('❌ Błąd tworzenia commit:', errorText)
        throw new Error(`Failed to create commit: ${newCommitResponse.status}`)
      }

      const newCommitData = await newCommitResponse.json()
      console.log('✅ New commit SHA:', newCommitData.sha)

      // Update reference
      console.log('🔄 Aktualizuję referencję...')
      const updateRefResponse = await fetch(
        `https://api.github.com/repos/${repoOwner}/${repoName}/git/refs/heads/${branch}`,
        {
          method: 'PATCH',
          headers,
          body: JSON.stringify({
            sha: newCommitData.sha,
            force: false
          })
        }
      )

      if (!updateRefResponse.ok) {
        const errorText = await updateRefResponse.text()
        console.error('❌ Błąd aktualizacji referencji:', errorText)
        throw new Error(`Failed to update reference: ${updateRefResponse.status}`)
      }

      console.log('✅ Synchronizacja zakończona!')

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Changes committed and pushed successfully',
          commitSha: newCommitData.sha,
          filesCount: files.length,
          foldersCount: folders.size
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    throw new Error('Invalid action')

  } catch (error) {
    console.error('❌ Błąd Edge Function:', error)
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Unknown error'
      }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})